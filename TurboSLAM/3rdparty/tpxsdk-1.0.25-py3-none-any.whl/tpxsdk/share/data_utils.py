﻿# -*- coding: utf-8 -*-
# 数据单位转换/数据处理/类型判读等工具类
import math


def rad2deg(rad):
    """
    弧度转度
    """
    return rad * 180.0 / math.pi


def deg2rad(deg):
    """
    度转弧度
    """
    return deg * math.pi / 180.0


def feet2meter(val):
    """
    米转英寸
    """
    return 0.3048 * val


def meter2feet(val):
    """
    米转英寸
    """
    return val / 0.3048


def kmph2mps(val):
    """
    从km/h到m/s
    """
    return val / 3.6


def mps2kmph(val):
    """
    从m/s到km/h
    """
    return val * 3.6


def wrap_pi(radian):
    """
    wrap an angle in radians to -PI ~ PI (equivalent to +- 180 deg)
    """
    res = wrap_2pi(radian)
    if res > math.pi:
        res -= math.pi * 2
    return res


def wrap_2pi(radian):
    """
    wrap an angle in radians to 0 ~ 2PI
    """
    res = radian % (math.pi * 2)
    if res < 0:
        res += math.pi * 2
    return res


def wrap_360(deg):
    """
    wrap an angle in deg to 0 ~ 360
    """
    return rad2deg(wrap_2pi(deg2rad(deg)))


def wrap_180(deg):
    """
    wrap an angle in deg to -180 ~ +180
    """
    return rad2deg(wrap_pi(deg2rad(deg)))


def constrain(val, min_val, max_val):
    """
    Limit the value between min and max
    """
    if val < min_val:
        return min_val
    if val > max_val:
        return max_val

    return val


def quat_from_euler_rad(euler):
    cr2 = math.cos(euler[0] * 0.5)
    cp2 = math.cos(euler[1] * 0.5)
    cy2 = math.cos(euler[2] * 0.5)
    sr2 = math.sin(euler[0] * 0.5)
    sp2 = math.sin(euler[1] * 0.5)
    sy2 = math.sin(euler[2] * 0.5)

    q0 = cr2 * cp2 * cy2 + sr2 * sp2 * sy2
    q1 = sr2 * cp2 * cy2 - cr2 * sp2 * sy2
    q2 = cr2 * sp2 * cy2 + sr2 * cp2 * sy2
    q3 = cr2 * cp2 * sy2 - sr2 * sp2 * cy2
    return [q0, q1, q2, q3]
