# -*- coding: utf-8 -*-
import serial
import threading
import logging
import time
import inspect

from tpxsdk.mission.flycmd_item import *
from tpxsdk.tplink.link_def import *
from tpxsdk.tplink.link_utils import *
from tpxsdk.tplink.rsp_code import RspCode
from tpxsdk.tplink.telemetry import *
from tpxsdk.uobject.uobj_base import UObjBase

TPLINK_VERSION = '2.6.8'
#----------------------------------------------------------------
# 飞控通讯协议
#----------------------------------------------------------------
class TPLink(object):
    def __init__(self, port_num, owner):
        #region 私有成员
        self._rcv_buf = bytearray(512)  # 数据接收缓冲区
        self._rcv_len = 0               # TPLINK对象名称
        self._comm = None               # 当前关联通讯接口
        self._rcv_task = None           # 通讯接口接收线程
        self._is_running = False        # 通讯接口接收线程运行标记
        self._alloc_sn = 0              # 用于分配报文序列号
        self._wait_sn = 255             # 用于记录等待响应报文的序列号
        self._locker = threading.Lock() # Link使用线程锁(用于异步)
        self._rsp_rdy = False           # 响应报文是否就绪标记
        self._rsp_code = RspCode.RSP_UNKNOWN
        self.heart_beat_task = None     # 心跳报文发送线程
        self.is_platform_connected = True   # 是否连接平台(云盒链路失效时为False)
        #endregion

        #region 回调函数
        self.cb_tlm_rcv_event = None
        self.cb_heart_beat_event = None
        self.cb_txt_tlm_rcv_event = None
        self.cb_code_tlm_rcv_event = None
        #endregion

        # region 公共成员
        self.Name = ''              # TPLINK对象名称
        self.DevAddr = 0xFF         # Link对象关联的设备ID(默认广播地址)
        self.Owner = owner          # Link对象所属者
        self.DebugEn = False        # 是否使能Debug模式
        self.Header = FrameHeader() # 当前最新帧头数据内容(不含前导码)
        self.RspData = bytearray()  # 响应报文数据字节数组
        self.RspTimeOut = 1.0       # 响应超时时间,单位秒
        self.open(port_num)
        # endregion

    def _put_char(self, c):
        # 过滤无效帧头数据
        if 0 == self._rcv_len and LinkDef.Header1 != c:
            return
        if 1 == self._rcv_len and LinkDef.Header2 != c:
            self._rcv_len = 0
            return

        self._rcv_buf[self._rcv_len] = c
        self._rcv_len += 1

        if self._rcv_len < LinkDef.MinPkSize:
            return

        if self._rcv_len > LinkDef.MaxPkSize:  # Overflow
            self._rcv_len = 0
            return

        if self._rcv_len == self._rcv_buf[2]:
            self._analyze(self._rcv_buf, self._rcv_len)
            self._rcv_len = 0  # For next packet

        return

    @staticmethod
    def _can_accept(data, sz):
        if data[0] != LinkDef.Header1 or data[1] != LinkDef.Header2:
            return False
        # logging.info (' '.join(format(data[i], '02x') for i in range(sz)))
        # 计算并验证校验和
        exp = data[sz - 2] + data[sz - 1] * 256
        ret = crc16(data[2:sz - 2])
        return ret == exp

    def _proc_response(self, data):
        """
        处理响应报文
        Args:
            data (byte[]): 接收到的响应负载数据
        """
        if self._wait_sn != self.Header.Sn:
            logging.warning(f'Invalid SN:{self._wait_sn}!= {self.Header.Sn}')
            return

        i = 0
        self._rsp_code = RspCode(gen_word(data[0], data[1]))
        # 复制负载数据(过滤响应码)
        self.RspData = bytearray(len(data) - 2)
        for c in data[2:]:
            self.RspData[i] = c
            i += 1

        # 通知RSP数据到达
        self._rsp_rdy = True

    @staticmethod
    def _proc_heart_beat(data):
        """
        心跳帧处理函数
        Args:
            data (bytes): 心跳帧负载
        """
        uid = gen_uint32(data)
        dev_type = data[4]
        logging.debug(f'HeartBeat: DevType={dev_type} UID={uid}')

    def _proc_telemetry(self, data):
        # 遥测报文处理:
        logging.debug(f'RCV telemetry {str(TlmType(data[0]).name)}')
        std_tlm = None
        if TlmType.STD0 == data[0]:
            std_tlm = StdTlm0()
        elif TlmType.STD1 == data[0]:
            std_tlm = StdTlm1()
        elif TlmType.STD2 == data[0]:
            std_tlm = StdTlm2()
        elif TlmType.STD3 == data[0]:
            std_tlm = StdTlm3()
        elif TlmType.STD4 == data[0]:
            std_tlm = StdTlm4()
        if std_tlm is not None:
            try:
                std_tlm.unserialize(data[1:])
                if self.Owner is not None:
                    self.Owner.on_std_tlm_rcv_event(std_tlm)
            except Exception as e:
                logging.error(f'std tlm proc fail: {e}')
            return

        if TlmType.TXT == data[0]:
            tlm_txt = bytes(data[1:])
            if self.Owner is not None:
                self.Owner.on_txt_tlm_rcv_event(tlm_txt)
            if self.cb_txt_tlm_rcv_event is not None:
                self.cb_txt_tlm_rcv_event(tlm_txt)
            logging.info(tlm_txt)
            return

        if TlmType.CODE == data[0]:
            tlm_code = RspCode(gen_word(data[1],data[2]))
            logging.info(f'TlmCode:{tlm_code}')
            if self.Owner is not None:
                self.Owner.on_code_tlm_rcv_event(tlm_code)
            if self.cb_code_tlm_rcv_event is not None:
                self.cb_code_tlm_rcv_event(tlm_code)
            return

        if TlmType.GIMBAL == data[0]:
            gimbal_tlm = GimbalTlm()
            try:
                gimbal_tlm.unserialize(data[1:])
                if self.Owner is not None:
                    self.Owner.on_gimbal_tlm_rcv_event(gimbal_tlm)
            except Exception as e:
                logging.error(f'Gimbal tlm proc fail:{e}')
            return

        if TlmType.BCST == data[0]:
            btlm = BcstTlm()
            try:
                btlm.unserialize(data[1:])
                if self.Owner is not None:
                    self.Owner.on_bcst_tlm_rcv_event(btlm)
            except Exception as e:
                logging.error(f'BCST tlm proc fail:{e}')
            return

    def _analyze(self, data, sz):
        """
        对接收到的完整报文进行解析处理
        """
        if not self._can_accept(data, sz):
            return
        self.Header.PayloadLen = data[2]
        self.Header.SrcAddr = data[3]
        self.Header.DstAddr = data[4]
        self.Header.Sn = data[5]

        if 0 == self.Header.Sn:  # Telemetry Packets
            self._proc_telemetry(data[6:sz - 2])
            if self.cb_tlm_rcv_event is not None:
                self.cb_tlm_rcv_event()
            return

        if 0xFF == self.Header.Sn:
            # 心跳帧 [建立设备地址表]
            if data[6] == LinkCmd.HEART_BEAT:
                self._proc_heart_beat(data[7:sz - 2])
                if self.cb_heart_beat_event is not None:
                    self.cb_heart_beat_event()
            return

        # Response Packets
        self._proc_response(data[6:sz - 2])

    def _proc_data_received(self):
        """
        从通讯接口接收到数据,基于字节流方式解析
        """
        while self._is_running:
            data = self._comm.read_all()
            if data is None or len(data) == 0:
                time.sleep(0.01)
                continue
            for c in data:
                self._put_char(c)

    def _heart_beat_send_task(self):
        """
        按周期1Hz发送心跳报文
        """
        while self._is_running:
            time.sleep(1)
            if not self.is_platform_connected:
                continue
            if self._locker.acquire(False):
                self._send_cmd_heart_beat()
                self._locker.release()
            logging.info('SND heart_beat')

    def _gen_send_data(self, payload, sz, sn):
        i = 0
        snd_buf = bytearray(sz + 8)
        snd_buf[i] = LinkDef.Header1
        i += 1
        snd_buf[i] = LinkDef.Header2
        i += 1
        snd_buf[i] = sz + 8
        i += 1  # 报文总长度
        snd_buf[i] = 0
        i += 1  # 报文源地址【地面站地址,默认为0】
        snd_buf[i] = self.DevAddr
        i += 1  # 报文目的地址
        snd_buf[i] = sn
        i += 1  # 报文序号

        for j in range(sz):
            snd_buf[i] = payload[j]
            i += 1

        crc = crc16(snd_buf[2:i])  # 计算CRC校验码
        snd_buf[i] = crc & 0xFF
        i += 1  # CRC低字节
        snd_buf[i] = (crc >> 8) & 0xFF
        i += 1  # CRC高字节

        return snd_buf

    def _alloc_packet_sn(self, need_rsp):
        """
        分配报文序列号(不需要响应帧的SN固定为0xFF)
        """
        if not need_rsp:
            return 0xFF

        self._alloc_sn += 1
        self._alloc_sn %= 256

        # 序列号0x00 预留给遥测报文
        if 0 == self._alloc_sn:
            self._alloc_sn = 1

        # 序列号0xFF 预留给心跳报文和其他不需要响应的报文
        if 0xFF == self._alloc_sn:
            self._alloc_sn = 1

        # 如果该报文等待响应,记录待响应报文序列号
        self._wait_sn = self._alloc_sn

        return self._alloc_sn

    # 通过通讯接口组包发送负载数据
    def _send_packet(self, payload, sz, need_rsp=False):
        new_sn = self._alloc_packet_sn(need_rsp)
        snd_buf = self._gen_send_data(payload, sz, new_sn)
        try:
            self._comm.write(snd_buf)
        except serial.SerialTimeoutException as e:
            logging.error(f"COM Timeout:{e}")
        except serial.SerialException as e:
            logging.error(f"COM Exp:{e}")
        if self.DebugEn:
            logging.info('SND:' + ' '.join(format(x, '02X') for x in snd_buf))

    #----------------------------------------------------------------
    # 公共成员函数集合
    #----------------------------------------------------------------
    def open(self, port_name):
        """
        打开指定通讯接口,建立数据链连接
        Args:
            port_name (string): 通讯接口名称, 例如COM1 、ttyTHS0
        Returns:
            bool: 操作是否成功
        """
        try:
            self._comm = serial.Serial(
                port=port_name,
                baudrate=115200,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=1,
                write_timeout=1)
            ret = self._comm.is_open
        except serial.SerialException as e:
            logging.error(e)  # 打印异常信息
            ret = False

        if ret:
            self._is_running = True
            self._rcv_task = threading.Thread(target=self._proc_data_received, daemon=True)
            self._rcv_task.name = f'{self.Name}_RcvThread'
            self._rcv_task.start()
            self.heart_beat_task = threading.Thread(target=self._heart_beat_send_task, daemon=True)
            self.heart_beat_task.name = f'{self.Name}_HeartBeatThread'
            self.heart_beat_task.start()

        return ret

    def close(self):
        if self._comm is None:
            return
        self._is_running = False
        self._comm.close()

    @property
    def is_opened(self):
        """
        Link是否打开,可进行正常收发
        """
        if self._comm is None:
            return False
        return self._comm.is_open

    #------------------------------------------------------------------------------
    # 任务相关函数集合
    #------------------------------------------------------------------------------
    def _send_cmd_mission_query_flyadmin(self, mis_id: int):
        """
        发送任务查询指令(查询FlyAdmin)
        """
        if not self.is_opened:
            return
        i = 0
        payload = bytearray(LinkDef.MaxPkSize)
        payload[i] = LinkCmd.MISSION_QUERY
        i += 1
        payload[i] = mis_id
        i += 1
        payload[i] = MisSubCmd.FLY_ADMIN
        i += 1

        self._send_packet(payload, i, True)
        logging.debug(f'MissionQuery:Flyadmin {mis_id}')

    def _send_cmd_mission_query_flyitem(self, mis_id: int, step: int):
        """
        发送任务查询指令(查询FlyItem)
        """
        if not self.is_opened:
            return
        i = 0
        payload = bytearray(LinkDef.MaxPkSize)
        payload[i] = LinkCmd.MISSION_QUERY
        i += 1
        payload[i] = mis_id
        i += 1
        payload[i] = MisSubCmd.FLY_ITEM
        i += 1
        payload[i] = word_lo(step)
        i += 1
        payload[i] = word_hi(step)
        i += 1
        self._send_packet(payload, i, True)
        logging.debug(f'MissionQuery:Flyadmin {mis_id} Flyitem[{step}]')

    def _send_cmd_mission_edit_flyadmin(self, mis_id: int, count: int, crc: int):
        """
        发送任务编辑指令(编辑FlyAdmin)
        """
        if not self.is_opened:
            return

        i = 0
        payload = bytearray(LinkDef.MaxPkSize)
        payload[i] = LinkCmd.MISSION_EDIT
        i += 1
        payload[i] = mis_id
        i += 1
        payload[i] = MisSubCmd.FLY_ADMIN
        i += 1
        payload[i] = word_lo(count)
        i += 1
        payload[i] = word_hi(count)
        i += 1
        payload[i] = word_lo(crc)
        i += 1
        payload[i] = word_hi(crc)
        i += 1
        self._send_packet(payload, i, True)
        logging.debug(f'MissionEdit:FlyAdmin {mis_id} {count} {crc}')

    def _send_cmd_mission_edit_flyitem(self, mis_id: int, step: int, item):
        """
        发送任务编辑指令(编辑FlyItem)
        """
        if not self.is_opened:
            return

        i = 0
        payload = bytearray(LinkDef.MaxPkSize)
        payload[i] = LinkCmd.MISSION_EDIT
        i += 1
        payload[i] = mis_id
        i += 1
        payload[i] = MisSubCmd.FLY_ITEM
        i += 1
        payload[i] = (step & 0xFF)
        i += 1
        payload[i] = (step >> 8) & 0xFF
        i += 1
        p_data = item.Data.get_bytes()
        for idx in range(len(p_data)):
            payload[i] = p_data[idx]
            i += 1
        self._send_packet(payload, i, True)
        logging.debug(f'MissionEdit:FlyCmd[{step}]')

    def _send_cmd_mission_edit_update(self, mis_id: int):
        """
        发送任务编辑指令(任务加载切换)
        """
        if not self.is_opened:
            return
        i = 0
        payload = bytearray(LinkDef.MaxPkSize)
        payload[i] = LinkCmd.MISSION_EDIT
        i += 1
        payload[i] = mis_id
        i += 1
        payload[i] = MisSubCmd.MIS_UPDATE
        i += 1
        self._send_packet(payload, i, True)
        logging.debug(f'MissionEdit:MIS_UPDATE {mis_id}')

    def _send_cmd_rtcm_update(self, data: list):
        """
        向飞控发送RTCM数据 支持RTK功能
        Args:
            data (byte array): RTCM差分修正数据
        """
        if not self.is_opened:
            return

        i = 0
        payload = bytearray(LinkDef.MaxPkSize)
        payload[i] = LinkCmd.RTCM_UPDATE
        i += 1
        for b in data:
            payload[i] = b
            i += 1
        self._send_packet(payload, i)

    def _send_cmd_do_action(self, sub_cmd: int, para: bytes, need_rsp=True):
        """
        发送DoAction指令

        Args:
            sub_cmd (int): 子级命令编码
            para ([]): 命令参数数据数组
            need_rsp(bool): 是否需要反馈信息
        """
        if not self.is_opened:
            return

        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.DO_ACTION
        payload[1] = sub_cmd  # 子级命令编码
        i = 2
        for b in para:
            payload[i] = b
            i += 1
        self._send_packet(payload, i, need_rsp)

    def _send_cmd_write_tag_msg(self, tag_id: int, str_msg: str):
        """
        DoAction指令工具函数-写入TagMessage
        Args:
            tag_id (byte): Tag信息ID编号
            str_msg (string): 待写入数据,不得超过32字节
        """
        msg_bytes = str_msg.encode()
        para = bytearray(2 + len(msg_bytes))
        para[0] = 1
        para[1] = tag_id
        i = 2
        for b in msg_bytes:
            para[i] = b
            i += 1

        self._send_cmd_do_action(ActionSubCmd.TAG_MSG, para, True)

    def _send_cmd_read_tag_msg(self, tag_id: int):
        """
        DoAction指令工具函数-读取TagMessage
        Args:
            tag_id (byte): Tag信息ID编号
        """
        para = bytes([0, tag_id])
        self._send_cmd_do_action(ActionSubCmd.TAG_MSG, para, True)

    def _send_cmd_lightctrl(self, isOn:bool):
        """
        DoAction指令工具函数-照明系统控制
        Args:
            isOn (byte): True开启, False关闭
        """
        para = bytes([1]) if isOn else bytes([0])
        self._send_cmd_do_action(ActionSubCmd.LIGHT, para, False)

    def _send_cmd_chute(self):
        """
        DoAction指令工具函数-降落伞开伞控制请求指令
        """
        self._send_cmd_do_action(ActionSubCmd.CHUTE, [], False)

    def _send_cmd_ioctrl(self, pin:int, isSet:bool):
        """
        DoAction指令工具函数-GPIO 控制请求指令
        """
        para = bytes([pin, 1]) if isSet else bytes([pin, 0])
        self._send_cmd_do_action(ActionSubCmd.IOCTRL, para, False)

    def _send_cmd_pwmctrl(self, ch:int, plus:int):
        """
        DoAction指令工具函数-PWM 输出控制请求指令
        """
        para = bytes([ch, word_lo(plus), word_hi(plus)])
        self._send_cmd_do_action(ActionSubCmd.PWMCTRL, para, False)

    #------------------------------------------------------------------------------
    # 飞行控制模式函数集合
    #------------------------------------------------------------------------------
    def _send_cmd_set_flight_mode(self, fm, fs):
        """
        发送飞行模式设置指令
        Args:
            fm (byte): 目标控制模式
            fs (byte): 目标控制子模式
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.SET_FLIGHT_MODE
        payload[1] = (fs << 4 | fm)  # 组装目标模式和子模式
        i = 2
        self._send_packet(payload, i, True)
        logging.debug('SendCmdSetFlightMode')

    def _send_cmd_hover_enter(self):
        """
        DoAction指令工具函数-进入Hover模式
        """
        if not self.is_opened:
            return

        self._send_cmd_do_action(ActionSubCmd.HOVER, bytes([1]), True)
        logging.debug('SendCmdEnterHover')

    def _send_cmd_hover_leave(self):
        """
        DoAction指令工具函数-退出Hover模式
        """
        if not self.is_opened:
            return

        self._send_cmd_do_action(ActionSubCmd.HOVER, bytes([0]), True)
        logging.debug('SendCmdExitHover')

    def _send_cmd_trace_obj(self, enabled):
        """
        DoAction指令工具函数-跟踪模式启停控制
        Args:
            enabled (bool): 是否使能跟踪模式
        """
        if not self.is_opened:
            return
        self._send_cmd_do_action(ActionSubCmd.TRACE_OBJ, bytes([1]) if enabled else bytes([0]), True)
        logging.debug(f'SendCmdTraceObj {enabled}')

    def _send_cmd_takeoff(self, rel_alt: float):
        """
        DoAction指令工具函数-自主起飞
        """
        if not self.is_opened:
            return
        i = 0
        para = bytearray(4)
        for b in int.to_bytes(int(rel_alt * 100), 4, 'little', signed=True):
            para[i] = b
            i += 1  # 相对高度cm
        self._send_cmd_do_action(ActionSubCmd.TAKEOFF, para, True)
        logging.debug('SendCmdTakeoff')

    def _send_cmd_rtl(self):
        """
        返航指令函数
        """
        if not self.is_opened:
            return

        self._send_cmd_set_flight_mode(FlightMode.AUTO, FlightStage.RTL)
        logging.debug('SendCmdRTL')

    def _send_cmd_offboard_req(self, reqcode, param: bytearray, need_rsp=True):
        """
        外部模式请求指令函数
        """
        if not self.is_opened:
            return

        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.OFFBOARD_REQ
        payload[1] = reqcode
        i = 2
        # 加载参数数据
        if param is not None:
            for b in param:
                payload[i] = b
                i += 1
        self._send_packet(payload, i, need_rsp)
        logging.debug('SendCmdOffboardReq')

    #------------------------------------------------------------------------------
    # 吊舱控制函数集合
    #------------------------------------------------------------------------------
    def _send_cmd_pod_move_up(self):
        """
        DoAction指令工具函数-吊舱移动-上
        """
        if not self.is_opened:
            return
        para = bytes([PodSubCmd.MOVE, PodMoveCode.UP])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug('SendCmdPodMoveUp')

    def _send_cmd_pod_move_down(self):
        """
        DoAction指令工具函数-吊舱移动-下
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.MOVE, PodMoveCode.DOWN])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug('SendCmdPodMoveDown')

    def _send_cmd_pod_move_left(self):
        """
        DoAction指令工具函数-吊舱移动-左
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.MOVE, PodMoveCode.LEFT])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug('SendCmdPodMoveLeft')

    def _send_cmd_pod_move_right(self):
        """
        DoAction指令工具函数-吊舱移动-右
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.MOVE, PodMoveCode.RIGHT])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug('SendCmdPodMoveRight')

    def _send_cmd_pod_move_stop(self):
        """
        DoAction指令工具函数-吊舱移动-停止
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.MOVE, PodMoveCode.STOP])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug('SendCmdPodMoveStop')

    def _send_cmd_pod_move_zero(self):
        """
        DoAction指令工具函数-吊舱移动-归中
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.MOVE, PodMoveCode.ZERO])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug('SendCmdPodMoveZero')

    def _send_cmd_pod_trace_ctrl(self, enable, x, y):
        """
        DoAction指令工具函数-吊舱凝视锁定跟踪控制
        Args:
            enable (bool): 使能控制标记
            x (float): 目标像素坐标百分比
            y (float): 目标像素坐标百分比
        """
        if not self.is_opened:
            return

        para = bytearray(10)
        para[0] = PodSubCmd.TRACE
        para[1] = 1 if enable else 0
        i = 2
        for b in struct.pack('f', x):
            para[i] = b
            i += 1
        for b in struct.pack('f', y):
            para[i] = b
            i += 1

        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug('SendCmdPodTraceCtrl')

    def _send_cmd_pod_set_angle(self, yaw, pitch):
        """
        DoAction指令工具函数-吊舱控制-设置目标角度
        Args:
            yaw (float): 目标方位角,deg
            pitch (float): 目标俯仰角,deg
        """
        if not self.is_opened:
            return

        para = bytearray(10)
        para[0] = PodSubCmd.ANGLE
        para[1] = 0
        i = 2
        for b in struct.pack('f', yaw):
            para[i] = b
            i += 1
        for b in struct.pack('f', pitch):
            para[i] = b
            i += 1

        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug('SendCmdPodSetAngle')

    def _send_cmd_pod_osd_ctrl(self, enable):
        """
        DoAction指令工具函数-吊舱控制-OSD
        Args:
            enable (bool): 使能控制标记
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.OSD, 1 if enable else 0])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug('SendCmdPodOSDCtrl')

    def _send_cmd_pod_lidar_ctrl(self, enable):
        """
        DoAction指令工具函数-吊舱控制-测距
        Args:
            enable (bool): 使能控制标记
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.LIDAR, 1 if enable else 0])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug(f'SendCmdPodLidarCtrl {enable}')

    def _send_cmd_pod_snap(self):
        """
        DoAction指令工具函数-吊舱控制-拍照
        """
        if not self.is_opened:
            return

        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, bytes([PodSubCmd.SNAP]))
        logging.debug('SendCmdPodSnap')

    def _send_cmd_pod_set_zoom(self, zoom):
        """
        DoAction指令工具函数-吊舱控制-变倍
        Args:
            zoom (byte): 变倍倍数
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.ZOOM, zoom])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug(f'SendCmdPodSetZoom {zoom}')

    def _send_cmd_pod_record_ctrl(self, enable):
        """
        DoAction指令工具函数-吊舱控制-录像
        Args:
            enable (bool): 使能控制标记
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.RECORD, 1 if enable else 0])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug(f'SendCmdPodRecordCtrl {enable}')

    def _send_cmd_pod_set_video(self, video_src):
        """
        DoAction指令工具函数-吊舱视频源设置
        Args:
            video_src (byte): 吊舱源编码
        """
        if not self.is_opened:
            return

        para = bytes([PodSubCmd.VIDEOSRC, video_src])
        self._send_cmd_do_action(ActionSubCmd.POD_CTRL, para)
        logging.debug(f'SendCmdPodSetVideo {video_src}')

    def _send_cmd_guide_enter(self, lat: float, lng: float, rel_alt: float, radius=0):
        """
        DoAction指令工具函数-进入引导模式

        Args:
            lat (float): 引导点位置纬度
            lng (float): 引导点位置经度
            rel_alt (float): 引导点位置相对高度
            radius (int, optional): 引导半径. Defaults to 0.
        """
        if not self.is_opened:
            return

        i = 0
        para = bytearray(16)
        for b in int.to_bytes(int(lat * 1e7), 4, 'little', signed=True):
            para[i] = b
            i += 1  # 纬度*1e7
        for b in int.to_bytes(int(lng * 1e7), 4, 'little', signed=True):
            para[i] = b
            i += 1  # 经度*1e7
        for b in int.to_bytes(int(rel_alt * 100), 4, 'little', signed=True):
            para[i] = b
            i += 1  # 相对高度cm
        for b in int.to_bytes(int(radius * 100), 4, 'little', signed=True):
            para[i] = b
            i += 1  # 引导点半径cm 【正负号代表盘旋方向】

        self._send_cmd_do_action(ActionSubCmd.GUIDE, para, True)
        logging.debug('SendCmdEnterGuide')

    def _send_cmd_guide_leave(self):
        """
        DoAction指令工具函数-离开引导模式
        """
        if not self.is_opened:
            return

        self._send_cmd_do_action(ActionSubCmd.GUIDE, bytes([]), True)
        logging.debug('SendCmdExitGuide')

    def _send_cmd_heart_beat(self):
        """
        发送心跳报文
        UDEV_TYPE_CMPT 0x07U
        UID 0x11223344
        """
        if not self.is_opened:
            return
        i = 0
        payload = bytearray(LinkDef.MaxPkSize)
        payload[i] = LinkCmd.HEART_BEAT
        i += 1
        payload[i] = 0x11
        i += 1
        payload[i] = 0x22
        i += 1
        payload[i] = 0x33
        i += 1
        payload[i] = 0x44
        i += 1
        payload[i] = 0x07
        i += 1  # Device type
        self._send_packet(payload, i)
        logging.debug('SendCmdHeartBeat')

    def _send_cmd_enter_udisk(self):
        """
        发送进入U盘模式指令
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.ENTER_UDISK
        self._send_packet(payload, 1)
        logging.debug('SendCmdEnterUDisk')

    def _send_cmd_joystick_update_btns(self, btns):
        """
        发送Joystick按钮状态信息
        Args:
            btns (byte): 按钮状态信息
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.JOYSTICK_UPDATE
        payload[1] = JoySubCmd.BTNS
        payload[2] = btns
        self._send_packet(payload, 3)
        logging.debug('SendCmdJoystickUpdate')

    def _send_cmd_joystick_update_axis(self, axis: bytes):
        """
        发送Joystick轴状态信息
        Args:
            axis (bytes): 摇杆轴变量
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        # 最多支持5个轴【待完善】
        payload[0] = LinkCmd.JOYSTICK_UPDATE
        payload[1] = JoySubCmd.AXIS
        i = 2
        for b in axis:
            payload[i] = b
            i += 1

        self._send_packet(payload, i)
        logging.debug('SendCmdJoystickUpdate')

    def _send_cmd_visland_update(self, x: float, y: float, z: float, sta: int):
        """
        发送 VisLand 信息 (Sta:0=DISC,1=NODATA,2=GOOD)
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        i = 0
        payload[i] = LinkCmd.VISLAND_UPDATE
        i += 1

        x_cm = int(x * 100)
        y_cm = int(y * 100)
        z_cm = int(z * 100)
        payload[i] = word_lo(x_cm)
        payload[i+1] = word_hi(x_cm)
        i += 2
        payload[i] = word_lo(y_cm)
        payload[i+1] = word_hi(y_cm)
        i += 2
        payload[i] = word_lo(z_cm)
        payload[i+1] = word_hi(z_cm)
        i += 2

        payload[i] = sta
        i += 1
        self._send_packet(payload, i)
        logging.debug('send_cmd_visland_update')

    def _send_cmd_evo_update(self,
                             lat: float, lng: float, alt: float,
                             posx: float, posy: float, posz: float,
                             velx: float, vely: float, velz: float,
                             sta: int, nav_sta: int):
        """
        发送 EVO 更新信息
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        i = 0
        payload[i] = LinkCmd.EVO_UPDATE
        i += 1

        for b in int.to_bytes(int(lat * 1e7), 4, 'little', signed=True):
            payload[i] = b
            i += 1  # 纬度*1e7
        for b in int.to_bytes(int(lng * 1e7), 4, 'little', signed=True):
            payload[i] = b
            i += 1  # 经度*1e7
        for b in int.to_bytes(int(alt * 100), 4, 'little', signed=True):
            payload[i] = b
            i += 1  # 海拔cm

        for b in int.to_bytes(int(posx * 100), 4, 'little', signed=True):
            payload[i] = b
            i += 1
        for b in int.to_bytes(int(posy * 100), 4, 'little', signed=True):
            payload[i] = b
            i += 1
        for b in int.to_bytes(int(posz * 100), 4, 'little', signed=True):
            payload[i] = b
            i += 1

        vel = int.to_bytes(int(velx * 100), 4, 'little', signed=True)
        payload[i] = vel[0]
        payload[i+1] = vel[1]
        i += 2

        vel = int.to_bytes(int(vely * 100), 4, 'little', signed=True)
        payload[i] = vel[0]
        payload[i+1] = vel[1]
        i += 2

        vel = int.to_bytes(int(velz * 100), 4, 'little', signed=True)
        payload[i] = vel[0]
        payload[i+1] = vel[1]
        i += 2

        payload[i] = sta
        payload[i+1] = nav_sta
        i += 2

        self._send_packet(payload, i)
        logging.debug('send_cmd_evo_update')

    #----------------------------------------------------------------
    # UOBJ Meta 对象元数据读取操作
    #----------------------------------------------------------------
    def _send_cmd_get_uobj_meta(self, sub_cmd: UObjMetaSubCmd, para: list):
        """
        发送UObjMeta读取请求指令
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.READ_UOBJ_META
        payload[1] = sub_cmd
        i = 2
        if para is not None:
            for b in para:
                payload[i] = b
                i += 1

        self._send_packet(payload, i, True)
        logging.debug('SendCmdGetUObjMeta')

    #----------------------------------------------------------------
    # UOBJECT 对象读写操作
    #----------------------------------------------------------------
    def _send_cmd_get_uobj(self, uobj: UObjBase):
        """
        发送UOBJ读取指令
        Args:
            uobj (UObjBase): 待读取的UObj对象
        """
        if not self.is_opened:
            return
        self._send_cmd_get_field(uobj.field_id())
        logging.debug(f'SendCmdGetUObj {uobj.friend_nm()}')

    def _send_cmd_set_uobj(self, uobj: UObjBase, need_rsp=True, save=False):
        """
        发送UOBJ设置指令
        Args:
            uobj (UObjBase): 待设置对象
            need_rsp:是否有需要ACK
            save:是否保存参数
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.SET_SAVE_FIELD if save else LinkCmd.SET_FIELD
        i = 1
        field_id = uobj.field_id()
        for b in int.to_bytes(field_id, 4, 'little'):
            payload[i] = b
            i += 1
        for c in uobj.to_bytes():
            payload[i] = c
            i += 1

        self._send_packet(payload, i, need_rsp)
        logging.debug(f'SendCmdSetUObj {uobj.friend_nm()}')

    #----------------------------------------------------------------
    # Field 对象读写操作
    #----------------------------------------------------------------
    def _send_cmd_get_field(self, field_id: int):
        """
        发送根据FieldID的读取指令
        Args:
            field_id (int): Field ID
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.GET_FIELD
        i = 1
        for b in int.to_bytes(field_id, 4, 'little'):
            payload[i] = b
            i += 1

        self._send_packet(payload, i, True)
        logging.debug(f"SendCmdGetField {field_id}")

    def _send_cmd_get_field_str(self, field_nm):
        """
        发送根据FieldName的读取指令 [按照字符串方式]
        Args:
            field_nm (string): Field名称
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.GET_FIELD_STR
        i = 1
        for c in field_nm.encode('ascii'):
            payload[i] = c
            i += 1
        payload[i] = 0
        i += 1

        self._send_packet(payload, i, True)
        logging.debug(f'SendCmdGetField {field_nm}')

    def _send_cmd_set_field_str(self, field_nm: str, field_val: str, save=False):
        """
        发送Field设置指令 [按照字符串方式]
        Args:
            field_nm (string): Field 名称
            field_val (string): FieldID 值
            save (bool, optional): 是否保存参数
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.SET_SAVE_FIELD_STR if save else LinkCmd.SET_FIELD_STR
        i = 1
        for c in field_nm.encode('ascii'):
            payload[i] = c
            i += 1
        payload[i] = 0
        i += 1
        for c in field_val.encode('ascii'):
            payload[i] = c
            i += 1
        payload[i] = 0
        i += 1

        self._send_packet(payload, i, True)
        logging.debug(f"SendCmdSetField {field_nm}={field_val}")

    # ----------------------------------------------------------------
    # Setting 参数相关操作
    # ----------------------------------------------------------------
    def _send_cmd_save_setting(self):
        """
        发送所有参数保存操作请求命令
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.SAVE_SETTING
        self._send_packet(payload, 1, True)
        logging.debug("SendCmdSaveSetting(All)")

    def _send_cmd_save_setting_file(self):
        """
        发送所有参数保存到文件操作请求命令
        """
        if not self.is_opened:
            return
        payload = bytearray(LinkDef.MaxPkSize)
        payload[0] = LinkCmd.SAVE_SETTING_FILE
        self._send_packet(payload, 1, True)
        logging.debug("SendCmdSaveSettingFile")

    def prepare_for_rsp(self):
        self.RspData = bytearray()
        self._rsp_code = RspCode.RSP_UNKNOWN

    def wait_for_rsp(self) ->bool:
        ret = False
        for i in range(5):
            if self._rsp_rdy:
                self._rsp_rdy = False
                ret = True
                break
            time.sleep(0.2)
        return ret
    #----------------------------------------------------------------
    # 异步模式交互函数
    #----------------------------------------------------------------
    def do_cmd_get_uobj_meta(self, sub_cmd, para: list = None):
        """
        发送UObjMeta读取请求指令
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_get_uobj_meta(sub_cmd, para)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_get_field_str(self, field_nm):
        """
        发送Field读取指令
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        ret = None
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_get_field_str(field_nm)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code
                if RspCode.RSP_OK == rsp_code:
                    rsp_str = bytearray.decode(self.RspData, 'ascii')
                    rsp_str = rsp_str.replace(' ', '')# 删除所有空格
                    segs = rsp_str.split('\0')
                    if len(segs) == 2 and segs[0] == field_nm:
                        logging.info(f'{segs[0]}={segs[1]}')
                        ret = segs[1] # 分析获取结果,更新Admin数据内容

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return ret

    def do_cmd_get_uobj(self, uobj: UObjBase):
        """
        发送UOBJ读取指令
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        ret = None
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_get_uobj(uobj)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code
                if RspCode.RSP_OK == rsp_code:
                    if len(self.RspData) == uobj.size + 4:      # 负载数据包含4字节 FieldID
                        field_id = gen_uint32(self.RspData)
                        if field_id == uobj.field_id():         # 判断FieldID是否匹配
                            if uobj.update(self.RspData[4:]):   # 数据设置是否成功
                                ret = uobj

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return ret

    def do_cmd_set_uobj(self, uobj: UObjBase, need_rsp=True, save=False):
        """
        发送UOBJ设置指令
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_set_uobj(uobj, need_rsp, save)
            if self.wait_for_rsp():
                # 检测响应码是否正确
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_mission_query_flyadmin(self, mis_id: int):
        """
        发送任务查询指令(查询FlyAdmin) return [count, crc] or None
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        ret = None
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_mission_query_flyadmin(mis_id)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code
                if RspCode.RSP_OK == rsp_code:
                    if 6 == len(self.RspData):
                        if self.RspData[0] == mis_id and self.RspData[1] == MisSubCmd.FLY_ADMIN:
                            ret = [gen_word(self.RspData[2], self.RspData[3]), gen_word(self.RspData[4], self.RspData[5])]

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return ret

    def do_cmd_mission_query_flyitem(self, mis_id: int, step: int):
        """
        发送任务查询指令
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        ret = None
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_mission_query_flyitem(mis_id, step)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code
                if RspCode.RSP_OK == rsp_code:
                    if (LinkDef.FlyCmdItemSize + 4) == len(self.RspData):
                        if self.RspData[0] == mis_id and self.RspData[1] == 0x02:
                            cmd_step = gen_word(self.RspData[2], self.RspData[3])
                            if cmd_step == step:
                                cmd_item = FlyCmdItem(0)
                                cmd_item.set_bytes(self.RspData[4:16])
                                ret = cmd_item

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return ret

    def do_cmd_mission_edit_flyadmin(self, mis_id: int, count: int, crc: int):
        """
        发送任务编辑指令(编辑FlyAdmin)
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_mission_edit_flyadmin(mis_id, count, crc)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_mission_edit_flyitem(self, mis_id: int, step: int, item):
        """
        发送任务编辑指令(编辑FlyCmdItem)
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_mission_edit_flyitem(mis_id, step, item)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_mission_edit_update(self, mis_id: int):
        """
        发送任务编辑指令(任务加载切换)
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_mission_edit_update(mis_id)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_rtcm_update(self, data: list):
        """
        向飞控发送RTCM数据 支持RTK功能
        Args:
            data (byte array): RTCM差分修正数据
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        with self._locker:
            self._send_cmd_rtcm_update(data)
        logging.info(f'{inspect.currentframe().f_code.co_name} exit')

    def do_cmd_save_setting(self):
        """
        发送所有参数保存操作请求命令
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_save_setting()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_save_setting_file(self):
        """
        发送所有参数保存到文件操作请求命令
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_save_setting_file()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_write_tag_msg(self, tag_id: int, str_msg: str):
        """
        标签写操作
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_write_tag_msg(tag_id, str_msg)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_read_tag_msg(self, tag_id: int) -> str:
        """
        标签读操作
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        ret = ''
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_read_tag_msg(tag_id)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code
                if RspCode.RSP_OK == self._rsp_code:
                    ret = bytearray.decode(self.RspData, 'ascii')

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return ret

    def do_cmd_takeoff(self, rel_alt: float):
        """
        自主起飞
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_takeoff(rel_alt)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_rtl(self):
        """
        返航指令
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_rtl()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_hover_enter(self):
        """
        DoAction指令工具函数-进入Hover模式
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_do_action(ActionSubCmd.HOVER, bytes([1]), True)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_hover_leave(self):
        """
        DoAction指令工具函数-退出Hover模式
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_do_action(ActionSubCmd.HOVER, bytes([0]), True)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_guide_enter(self, lat: float, lng: float, rel_alt: float, radius=0):
        """
        DoAction指令工具函数-进入引导模式
        Args:
            lat (float): 引导点位置纬度
            lng (float): 引导点位置经度
            rel_alt (float): 引导点位置相对高度
            radius (int, optional): 引导半径. Defaults to 0.
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_guide_enter(lat, lng, rel_alt, radius)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_guide_leave(self):
        """
        DoAction指令工具函数-离开引导模式
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_guide_leave()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_set_field_str(self, field_nm: str, field_val: str, save=False):
        """
        发送Field设置指令 [按照字符串方式]
        Args:
            field_nm (string): Field 名称
            field_val (string): FieldID 值
            save (bool, optional): 是否保存参数
        """
        logging.info(f'{inspect.currentframe().f_code.co_name} {field_nm}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_set_field_str(field_nm, field_val, save)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name} {field_nm}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_pod_move_up(self):
        """
        DoAction指令工具函数-吊舱移动-上
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_pod_move_up()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_pod_move_down(self):
        """
        DoAction指令工具函数-吊舱移动-下
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_pod_move_down()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_pod_move_left(self):
        """
        DoAction指令工具函数-吊舱移动-左
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_pod_move_left()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_pod_move_right(self):
        """
        DoAction指令工具函数-吊舱移动-右
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_pod_move_right()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_pod_move_stop(self):
        """
        DoAction指令工具函数-吊舱移动-停止
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_pod_move_stop()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_pod_move_zero(self):
        """
        DoAction指令工具函数-吊舱移动-归中
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_pod_move_zero()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_pod_snap(self):
        """
        DoAction指令工具函数-吊舱控制-拍照
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_pod_snap()
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_pod_set_zoom(self, zoom):
        """
        DoAction指令工具函数-吊舱控制-变倍
        Args:
            zoom (byte): 变倍倍数
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_pod_set_zoom(zoom)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_pod_set_angle(self, yaw, pitch):
        """
        DoAction指令工具函数-吊舱控制-设置目标角度
        """
        logging.info(f'{inspect.currentframe().f_code.co_name}')
        rsp_code = RspCode.RSP_TIMEOUT
        with self._locker:
            self.prepare_for_rsp()
            self._send_cmd_pod_set_angle(yaw, pitch)
            if self.wait_for_rsp():
                rsp_code = self._rsp_code

        logging.info(f'{inspect.currentframe().f_code.co_name}: RspCode={rsp_code}')
        return rsp_code

    def do_cmd_visland_update(self, x: float, y: float, z: float, sta: int):
        """
        发送 VisLand 信息
        """
        with self._locker:
            self._send_cmd_visland_update(x, y, z, sta)

    def do_cmd_evo_update(self,
                          lat: float, lng: float, alt: float,
                          posx: float, posy: float, posz: float,
                          velx: float, vely: float, velz: float,
                          sta: int, nav_sta: int):
        """
        发送 EVO 信息
        """
        with self._locker:
            self._send_cmd_evo_update(lat, lng, alt,
                                      posx, posy, posz,
                                      velx, vely, velz, sta, nav_sta)

    def do_cmd_offboard_set_target_pos(self, coord:OffboardCoord, x: float, y: float, z: float):
        """
        发送 Offboard目标位置信息
        """
        para = bytearray(13)
        para[0] = coord
        i = 1
        if coord == OffboardCoord.NED or coord == OffboardCoord.FRD:
            for b in struct.pack('f', x):
                para[i] = b
                i += 1
            for b in struct.pack('f', y):
                para[i] = b
                i += 1
            for b in struct.pack('f', z):
                para[i] = b
                i += 1
        else:
            return # Not Supported

        with self._locker:
            self._send_cmd_offboard_req(OffboardSubCmd.SET_POS, para, False)

    def do_cmd_offboard_set_target_loc(self, lat: float, lng: float, alt: float):
        """
        发送 Offboard目标位置
        """
        para = bytearray(13)
        para[0] = OffboardCoord.WGS84
        i = 1
        for b in int.to_bytes(int(lat * 1e7), 4, 'little', signed=True):
            para[i] = b
            i += 1  # 纬度*1e7
        for b in int.to_bytes(int(lng * 1e7), 4, 'little', signed=True):
            para[i] = b
            i += 1  # 经度*1e7
        for b in struct.pack('f', alt):
            para[i] = b
            i += 1  # 海拔高度

        with self._locker:
            self._send_cmd_offboard_req(OffboardSubCmd.SET_POS, para, False)

    def do_cmd_offboard_set_target_vel(self, coord:OffboardCoord, x: float, y: float, z: float):
        """
        发送 Offboard目标速度
        """
        para = bytearray(13)
        para[0] = coord
        i = 1
        if coord == OffboardCoord.NED or coord == OffboardCoord.FRD:
            for b in struct.pack('f', x):
                para[i] = b
                i += 1
            for b in struct.pack('f', y):
                para[i] = b
                i += 1
            for b in struct.pack('f', z):
                para[i] = b
                i += 1
        else:
            return # Not Supported

        with self._locker:
            self._send_cmd_offboard_req(OffboardSubCmd.SET_VEL, para, False)

    def do_cmd_offboard_set_target_atti(self, roll: float, pitch: float, yaw: float):
        """
        发送 Offboard目标姿态
        """
        i = 0
        para = bytearray(12)
        for b in struct.pack('f', roll):
            para[i] = b
            i += 1
        for b in struct.pack('f', pitch):
            para[i] = b
            i += 1
        for b in struct.pack('f', yaw):
            para[i] = b
            i += 1

        with self._locker:
            self._send_cmd_offboard_req(OffboardSubCmd.SET_ATTI, para, False)

    def do_cmd_offboard_enter(self):
        with self._locker:
            self._send_cmd_offboard_req(OffboardSubCmd.ENTER, None, False)

    def do_cmd_offboard_leave(self):
        with self._locker:
            self._send_cmd_offboard_req(OffboardSubCmd.LEAVE, None, False)

    def do_cmd_enter_udisk(self):
        """
        发送切换U盘模式指令
        """
        with self._locker:
            self._send_cmd_enter_udisk()

    def do_cmd_pwmctrl(self, ch:int, plus:int):
        with self._locker:
            self._send_cmd_pwmctrl(ch, plus)