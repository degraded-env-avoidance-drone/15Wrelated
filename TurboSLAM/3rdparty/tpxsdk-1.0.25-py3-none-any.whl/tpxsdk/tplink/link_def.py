# -*- coding: utf-8 -*-
from enum import IntEnum

class LinkDef(IntEnum):
    """
    TPLink 通信协议相关定义
    """
    MinPkSize = 8    # 最小帧长度
    MaxPkSize = 128  # 最大帧长度
    Header1   = 0xA5 # 帧起始符号1
    Header2   = 0x5A # 帧起始符号2
    FlyCmdItemSize = 12


class TlmType(IntEnum):
    """
    遥测报文类型编码定义
    """
    STD0 = 0x00
    STD1 = 0x01
    STD2 = 0x02
    STD3 = 0x03
    STD4 = 0x04
    USR0 = 0x05
    USR1 = 0x06
    USR2 = 0x07
    USR3 = 0x08
    USR4 = 0x09
    HIL  = 0x0A
    TXT  = 0x0B
    CODE = 0x0C
    BCST = 0x20
    GIMBAL = 0x21
    OBST = 0x22


class FlightMode(IntEnum):
    """
    飞行模式定义【MC】
    """
    STAB     = 0 # 姿态模式
    ALTHOLD  = 1 # 定高模式
    LOITER   = 2 # 定点模式
    AUTO     = 3 # 自主模式
    FOLLOW   = 4 # 跟踪模式
    STRIKE   = 5 # 打击模式
    OFFBOARD = 6 # 外部模式


class FlightStage(IntEnum):
    """
    飞行模式子状态定义
    """
    IDLE    = 0 # 空闲状态
    TAKEOFF = 1 # 自主起飞
    WPNAV   = 2 # 航点模式
    CIRCLE  = 3 # 盘旋模式
    GUIDED  = 4 # 引导模式
    RTL     = 5 # 返航模式
    LAND    = 6 # 降落模式
    TRANS   = 7 # 转换模式
    HOVER   = 8 # 悬停模式


class LinkCmd(IntEnum):
    """
    报文命令码字定义
    """
    MISSION_EDIT       = 0x10 # Modify Mission Info
    MISSION_QUERY      = 0x11 # Query Mission  data
    RCIN_UPDATE        = 0x20 # Update radio control data
    SERVO_OUT          = 0x21 # Set servo out data
    JOYSTICK_UPDATE    = 0x22 # Update joystick control data
    FOLLOW_TARGET      = 0x23 # Update Follow target information
    VISLAND_UPDATE     = 0x24 # Update VisLand sensor data
    EVO_UPDATE         = 0x25 # Update VNS or LNS data
    HEART_BEAT         = 0x30 # Heart beat for device  report
    PASS_THROUGH       = 0x31 # Pass through data to device
    RTCM_UPDATE        = 0x32 # Send RTCM data to GNSS Receiver
    SET_FLIGHT_MODE    = 0x40 # Set flight mode
    DO_ACTION          = 0x41 # Do action by parameters
    ENTER_IAP          = 0xB1 # Set device to IAP mode
    ERASE_FLASH        = 0xB2 # Set device to erase flash
    DOWNLOAD_BIN       = 0xB3 # Set device to download firmware
    ENTER_UDISK        = 0xB4 # Set device to U-Disk mode
    SAVE_SETTING       = 0xCC # Save setting data to flash
    SAVE_SETTING_FILE  = 0xCD # Save setting data to file
    READ_UOBJ_META     = 0xE0 # Read UObject meta data
    GET_FIELD_STR      = 0xE1 # Get field value by field name
    SET_FIELD_STR      = 0xE2 # Set field value by field name
    SET_SAVE_FIELD_STR = 0xE3 # Set&save field by field name
    GET_FIELD          = 0xF0 # Get field value by ID
    SET_FIELD          = 0xF1 # Set field value by ID
    SET_SAVE_FIELD     = 0xF2 # Set&save field by ID
    OFFBOARD_REQ       = 0xF3 # Command request from offboard

class OffboardSubCmd(IntEnum):
    """
    Offboard请求指令码
    """
    SET_POS  = 0xB0 # Set Offboard target Position
    SET_VEL  = 0xB1 # Set Offboard target velocity
    SET_ATTI = 0xB2 # Set Offboard target attitude
    ENTER    = 0xB3 # Enter Offboard mode
    LEAVE    = 0xB4 # Leave Offboard mode

class OffboardCoord(IntEnum):
    """
    Offboard请求指令坐标系
    """
    FRD   = 0
    NED   = 1
    WGS84 = 2

class UObjMetaSubCmd(IntEnum):
    """
    UObject对象元数据读取指令
    """
    SIG = 0x00 # 读取UObject模板签名
    CLS = 0x01 # 读取UObject类元信息
    MEM = 0x02 # 读取UObject成员元信息


class ActionSubCmd(IntEnum):
    """
    DoAction操作子命令编码
    """
    FLY_ADMIN   = 0x00 # Mission subcmd for flyadmin
    FLY_ITEM    = 0x02 # Mission subcmd for flyitem
    MIS_UPATE   = 0x03 # Mission subcmd for update
    TAKEOFF     = 0xA0 # Do takeoff action
    JUMP        = 0xA1 # Do mission cmd step jump
    AUTH        = 0xA2 # Do certificate action
    GUIDE       = 0xA3 # Do GUIDE action
    TEST        = 0xA4 # Do System test action
    SET_FAKEGPS = 0xA5 # Do Set fake GPS mode
    SET_HILMODE = 0xA6 # Do Set HIL mode
    CALIB       = 0xA7 # Do System calibration
    SET_ADDR    = 0xA8 # Do Device address set
    FORMATION   = 0xA9 # Do drones formation
    WARHEAD     = 0xAA # Do WARHEAD control
    POD_CTRL    = 0xAB # Do Gimbal(POD) control
    TRACE_OBJ   = 0xAC # Trace Gimbal(POD) target
    TAG_MSG     = 0xAD # Set&Get Tag message to NVM
    LAND        = 0xAE # Do land action
    HOVER       = 0xAF # Do hover action
    LIGHT       = 0xB0 # Do light control action
    CHUTE       = 0xB1 # Do parachute control action
    RTL         = 0xB2 # Do RTL control action
    IOCTRL      = 0xB3 # Do GPIO control action
    PWMCTRL     = 0xB4 # Do PWM output control action

class MisSubCmd(IntEnum):
    """Mission操作子命令编码
    """
    FLY_ADMIN  = 0x00
    FLY_ITEM   = 0x02
    MIS_UPDATE = 0x03

class JoySubCmd(IntEnum):
    """
    Joystick操作子命令编码
    """
    BTNS = 0x00
    AXIS = 0x01

class PodSubCmd(IntEnum):
    """
    PodCtrl操作子命令编码
    """
    SNAP     = 0x00
    ZOOM     = 0x01
    ANGLE    = 0x02
    RECORD   = 0x03
    LIDAR    = 0x04
    OSD      = 0x05
    MOVE     = 0x06
    VIDEOSRC = 0x07
    TRACE    = 0x08
    SETADDR  = 0x09
    GETADDR  = 0x0A

class PodMoveCode(IntEnum):
    """
    吊舱伺服移动控制指令编码
    """
    STOP  = 0x00 # 停止
    UP    = 0x01 # 上移
    DOWN  = 0x02 # 下移
    LEFT  = 0x03 # 左移
    RIGHT = 0x04 # 右移
    ZERO  = 0xFF # 归中

class FrameHeader(object):
    """
    通用帧头数据内容 (不含前导码 2Byte)
    """

    def __init__(self):
        self.PayloadLen = 0  # 负载字段长度
        self.SrcAddr = 0  # 帧源地址
        self.DstAddr = 0  # 帧目的地址
        self.Sn = 0  # 帧序列号
