# -*- coding: utf-8 -*-
from enum import IntEnum
import re

class TokenType(IntEnum):
    """词元类型属性"""
    UNKNOWN = 0,  # 未知类型
    NUMBER = 1,   # 数值类型
    POINTER = 2,  # 指针类型 [XXX.XXX]
    REL_POS = 3,  # 相对坐标
    ABS_POS = 4,  # 绝对坐标
    AP_INT = 5,   # 指令词元
    PSEUDO = 6    # 伪指令词元


class FlyToken(object):
    """词元描述类"""
    def __init__(self, str_name: str, row):
        self.Name = str_name
        self.Type = TokenType.UNKNOWN
        self.Row = row
        # 根据名称形式推测词元基本类型
        ptn_abs = r'\((\d+(\.?\d+)?)([W|w|E|e])\s*,\s*(\d+(\.?\d+)?)([|S|s|N|n])\)'
        ptn_rel = r'\(([+|-]?\d+(\.?\d+)?)\s*,\s*([+|-]?\d+(\.?\d+)?)\)'
        ptn_num = r'(([+|-]?\d+(\.\d*)?|\.\d+)([eE][-+]?\d+)?)'

        # 匹配整数和浮点数
        if re.match(ptn_num, self.Name) is not None:
            self.Type = TokenType.NUMBER

        # 匹配FieldID域
        elif str_name.startswith('[') and str_name.endswith(']'):
            self.Name = str_name[1:-1]  # remove "[ ]"
            self.Type = TokenType.POINTER

        # 匹配绝对位置坐标
        elif re.match(ptn_abs, str_name) is not None:
            self.Type = TokenType.ABS_POS

        # 匹配相对位置坐标
        elif re.match(ptn_rel, str_name) is not None:
            self.Type = TokenType.REL_POS

        else:  # 未知类型
            self.Type = TokenType.UNKNOWN
