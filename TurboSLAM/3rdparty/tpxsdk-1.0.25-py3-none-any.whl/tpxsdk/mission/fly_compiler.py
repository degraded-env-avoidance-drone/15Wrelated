import os.path
import logging
from tpxsdk.mission.flycmd_admin import FlyCmdAdmin
from tpxsdk.mission.flycmd_item import *


# Fly命令编译器
class FlyCompiler(object):
    def __init__(self):
        self.CmdList = []
        self.FlyFile = ''
        self.FlyAdmin = FlyCmdAdmin()
        self.FastWpMode = False  # 是否使用快速航点模式
        self.AmslMode = False  # 导航指令是否使用绝对高度
        self.ErrorMsg = ''
        self._line_num = 0

    def _clean(self):
        """
        清理编译器状态
        """
        self.CmdList.clear()
        self.ErrorMsg = ''
        self.FastWpMode = False
        self.AmslMode = False
        self._line_num = 0

    def _syntax_analyze(self, tokens: list) -> bool:
        """
        语义分析
        """
        if len(tokens) == 0:
            return False
        # Find Processors by keywords
        cmd_item = self.FlyAdmin.get_by_name(tokens[0].Name)
        if cmd_item is None:
            return False
        # 处理FlyCmd指令
        return cmd_item.process(self, tokens)

    def _line_analyze(self, line: str) -> bool:
        line = line.strip()
        # 删除无效行尾
        if line.endswith('\n'):
            line = line[0:-1]

        # 处理注释行过滤(1)
        if line.startswith('#') or line.startswith('//'):
            return True

        # 处理注释行过滤(2)
        if '//' in line:
            line = line[0:line.index('//')].strip()

        # 进行切分获得有效词元Token
        tokens = []
        line_lex = []
        # 需要整词元匹配的前字符
        pre_match = '\0'
        for ch in line:
            if ch == '[' or ch == '(':
                pre_match = ch
                str_token = ''.join(line_lex).strip()
                if len(str_token) == 0:
                    line_lex.append(ch)
                    continue

                tokens.append(FlyToken(str_token, self._line_num))
                line_lex.clear()
                line_lex.append(ch)
                continue

            line_lex.append(ch)

            # 匹配到词元[XXX]或(XXX)
            if pre_match == '[' and ch == ']' or pre_match == '(' and ch == ')':
                str_token = ''.join(line_lex).strip()
                tokens.append(FlyToken(str_token, self._line_num))
                pre_match = '\0'
                line_lex.clear()
                continue

            # 处理词元结束情况之一：以下述分隔符为结尾
            if pre_match == '\0' and (ch == ' ' or ch == '\t' or ch == ','):
                line_lex.pop(-1)  # 去除尾部分割符号
                str_token = ''.join(line_lex).strip()
                if len(str_token) == 0:
                    continue

                tokens.append(FlyToken(str_token, self._line_num))
                line_lex.clear()

            # 处理词元结束情况之二：以关键词为结尾
            # Fixme: 此处实现比较丑陋,待改善
            if pre_match == '\0' and ch == '=':
                str_token = ''.join(line_lex).strip()
                if len(str_token) == 0:
                    continue

                tokens.append(FlyToken(str_token, self._line_num))
                line_lex.clear()

        # 最终剩余词元处理
        str_token = ''.join(line_lex).strip()
        if len(str_token) > 0:
            tokens.append(FlyToken(str_token, self._line_num))
        return self._syntax_analyze(tokens)

    # 核心处理用正则表达式
    def compile(self, fly_file) -> bool:
        if not os.path.exists(fly_file):
            return False
        self._line_num = 0
        with open(fly_file, 'r') as file:
            for line in file:
                self._line_num += 1
                ret = self._line_analyze(line)
                if not ret:
                    logging.error(f'Error Cmd: {line} | line {self._line_num}')
                    return False

        return True

    def decompile(self, fly_items):
        ret = ''
        self.CmdList.clear()
        for item in fly_items:
            inst = self.FlyAdmin.get_by_value(item.Id)
            inst.Data = item
            ret += inst.reverse()
            ret += '\n'
        return ret
