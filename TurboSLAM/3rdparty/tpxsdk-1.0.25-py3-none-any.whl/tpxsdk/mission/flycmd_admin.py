# -*- coding: utf-8 -*-
# 分词器管理器

from tpxsdk.mission.flycmd_item import *


class FlyCmdAdmin(object):
    def __init__(self):
        self.LineNum = -1
        self.Items = [
            InstAltKind(),
            InstCamCtrl(),
            InstCircleLeft(),
            InstCircleRight(),
            InstCircleSet(),
            InstClimb(),
            InstDelay(),
            InstFlyto(),
            InstFlyto1(),
            InstFlyto2(),
            InstFlyto3(),
            InstHover(),
            InstIOCtrl(),
            InstLand(),
            InstPODCtrl(),
            InstPWMCtrl(),
            InstSeederCtrl(),
            InstRepeat(),
            InstSetLandYaw(),
            InstSetLandAlt(),
            InstSetSpeed(),
            InstSetWpYaw(),
            InstTakeoff(),
            InstWaitClimb(),
            InstWaitFmt(),
            InstWaitSpin(),
            PseudoFastWp(),
            ]
        #logging.info(self.Items)

    def get_by_name(self, key_name):
        """根据关键词查找词元处理器
        为了兼容代码大小写混合方式,在此进行转换处理
        """
        for item in self.Items:
            if item.KeyName.lower() == key_name.lower():
                return item
        return None

    def get_by_value(self, key_val):
        """根据关键词查找词元处理器
        为了兼容代码大小写混合方式,在此进行转换处理
        """
        for item in self.Items:
            if item.KeyValue == key_val:
                return item
        return None
