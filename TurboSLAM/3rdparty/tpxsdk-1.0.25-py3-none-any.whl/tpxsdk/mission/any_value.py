# -*- coding: utf-8 -*-
import struct


class AnyValue(object):
    """
    4字节组成的Union数据类型，可表示 U8/U16/U32/S8/S16/S32/FP32
    """

    def __init__(self):
        self.TypeName = None
        self._bytes = bytearray(4)

    def _reset(self):
        self._bytes[0] = 0
        self._bytes[1] = 0
        self._bytes[2] = 0
        self._bytes[3] = 0

    @property
    def raw_bytes(self):
        return self._bytes

    @raw_bytes.setter
    def raw_bytes(self, val: list):
        self._bytes[0] = val[0]
        self._bytes[1] = val[1]
        self._bytes[2] = val[2]
        self._bytes[3] = val[3]
        pass

    @property
    def u8_val(self):
        return self._bytes[0]

    @u8_val.setter
    def u8_val(self, val):
        self._reset()
        self._bytes[0] = val

    @property
    def s8_val(self):
        return int.from_bytes([self._bytes[0]], byteorder='little', signed=True)

    @s8_val.setter
    def s8_val(self, val):
        r = val.to_bytes(1, byteorder='little', signed=True)
        self._reset()
        self._bytes[0] = r[0]

    @property
    def u16_val(self):
        return int.from_bytes(self._bytes[0:2], byteorder='little', signed=False)

    @u16_val.setter
    def u16_val(self, val):
        r = val.to_bytes(2, byteorder='little', signed=False)
        self._reset()
        self._bytes[0] = r[0]
        self._bytes[1] = r[1]
        pass

    @property
    def s16_val(self):
        return int.from_bytes(self._bytes[0:2], byteorder='little', signed=True)

    @s16_val.setter
    def s16_val(self, val):
        r = val.to_bytes(2, byteorder='little', signed=True)
        self._reset()
        self._bytes[0] = r[0]
        self._bytes[1] = r[1]
        pass

    @property
    def u32_val(self):
        return int.from_bytes(self._bytes, byteorder='little', signed=False)

    @u32_val.setter
    def u32_val(self, val):
        self._bytes = val.to_bytes(4, byteorder='little', signed=False)

    @property
    def s32_val(self):
        return int.from_bytes(self._bytes, byteorder='little', signed=True)

    @s32_val.setter
    def s32_val(self, val):
        self._bytes = val.to_bytes(4, byteorder='little', signed=True)

    @property
    def float_val(self):
        return struct.unpack('f', self._bytes)[0]

    @float_val.setter
    def float_val(self, val):
        self._bytes = struct.pack('f', val)
