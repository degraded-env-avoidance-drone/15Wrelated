from enum import IntEnum


class ParaType(IntEnum):
    EMPTY = 0  # Contains none parameter
    NUMBER = 1  # Value A Contains a number
    POINTER = 2  # Value A Contains a field identifier
    REL_POS = 3  # Value A and B Contains a relative waypoint, A is east and B is north
    ABS_POS = 4  # Value A and B Contains a absolute waypoint, A is longitude and B is latitude
