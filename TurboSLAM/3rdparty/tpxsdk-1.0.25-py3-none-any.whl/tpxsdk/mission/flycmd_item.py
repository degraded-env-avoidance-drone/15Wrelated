# -*- coding: utf-8 -*-
import struct

from tpxsdk.mission.any_value import *
from tpxsdk.mission.flycmd_id import *
from tpxsdk.mission.fly_token import *
from tpxsdk.mission.para_type import *

class FlyCmdItem(object):
    """
    描述Fly指令对象类
    """
    def __init__(self, cmd_id: int):
        self.Id = cmd_id
        self.P1 = 0
        self.P2 = 0
        self.P3 = AnyValue()
        self.P4 = AnyValue()

    def get_bytes(self):
        ret = bytearray(12)  # FlyCmdItem Fixed size
        ret[0] = self.Id
        ret[1] = self.P1

        val_bytes = struct.pack('h', self.P2)
        ret[2] = val_bytes[0]
        ret[3] = val_bytes[1]

        val_bytes = self.P3.raw_bytes
        ret[4] = val_bytes[0]
        ret[5] = val_bytes[1]
        ret[6] = val_bytes[2]
        ret[7] = val_bytes[3]

        val_bytes = self.P4.raw_bytes
        ret[8] = val_bytes[0]
        ret[9] = val_bytes[1]
        ret[10] = val_bytes[2]
        ret[11] = val_bytes[3]
        return ret

    def set_bytes(self, data: bytes):
        if len(data) != 12:
            return False
        self.Id = data[0]
        self.P1 = data[1]
        self.P2 = struct.unpack('H', data[2:4])[0]
        self.P3.raw_bytes = data[4:8]
        self.P4.raw_bytes = data[8:12]
        return True

class PseudoFastWp(object):
    def __init__(self):
        self.KeyName = 'fastwp'
        self.KeyValue = 0xFD
        self.Description = 'Marks the Next flyto cmd use fast waypoint mode.'
        self.IsPseudo = True

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        fly_cmp.FastWpMode = True
        return False

    def reverse(self) -> str:
        # not supported for Pseudo
        return ''


class InstFlyto(object):
    def __init__(self):
        self.KeyName = 'flyto'
        self.KeyValue = FlyCmdId.CMD_FLYTO
        self.Usage = "flyto (waypoint) [,alt]"
        self.Description = 'flyto (waypoint) [,alt]: Fly to the waypoint. The flyto command sets the desired heading'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2 and len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstFlyto()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type == TokenType.ABS_POS or tokens[0].Type == TokenType.REL_POS:
            # flyto (xxx, xxx)形式
            if wp_token_to_cmd_item_p1(tokens[0], cmd.Data):
                if len(tokens) == 2 and tokens[1].Type == TokenType.NUMBER:
                    cmd.Data.P2 = int(tokens[1].Name)

                # mark for fast waypoint mode
                if fly_cmp.FastWpMode:
                    cmd.Data.P1 |= 0x80
                fly_cmp.FastWpMode = False  # 仅对当前Flyto指令生效
                fly_cmp.CmdList.append(cmd)
                return True

            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        return False

    def reverse(self) -> str:
        ret = ''
        if self.Data.P1 & 0x80 > 0:
            ret = 'fastwp\r\n'
        str_wp = parse_wp_from_cmd_item2(self.Data)
        if self.Data.P2 == 0:
            ret += f'{self.KeyName} {str_wp}'
        else:
            ret += f"{self.KeyName} {str_wp}, {self.Data.P2}"

        return ret

class InstFlyto1(object):
    def __init__(self):
        self.KeyName = 'flyto1'
        self.KeyValue = FlyCmdId.CMD_FLYTO1
        self.Usage = "flyto1 (waypoint) [,alt]"
        self.Description = 'flyto1 (waypoint) [,alt]: Fly to the waypoint. The flyto1 command sets the desired heading'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2 and len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstFlyto1()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type == TokenType.ABS_POS or tokens[0].Type == TokenType.REL_POS:
            # flyto (xxx, xxx)形式
            if wp_token_to_cmd_item_p1(tokens[0], cmd.Data):
                if len(tokens) == 2 and tokens[1].Type == TokenType.NUMBER:
                    f_val = float(tokens[1].Name) * 10.0
                    cmd.Data.P2 = (int)(f_val)

                # mark for fast waypoint mode
                if fly_cmp.FastWpMode:
                    cmd.Data.P1 |= 0x80
                fly_cmp.FastWpMode = False  # 仅对当前Flyto指令生效
                fly_cmp.CmdList.append(cmd)
                return True

            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        return False

    def reverse(self) -> str:
        ret = ''
        if self.Data.P1 & 0x80 > 0:
            ret = 'fastwp\r\n'
        str_wp = parse_wp_from_cmd_item2(self.Data)
        if self.Data.P2 == 0:
            ret += f'{self.KeyName} {str_wp}'
        else:
            f_alt = int(self.Data.P2) * 0.1
            ret += f"{self.KeyName} {str_wp}, {f_alt}"

        return ret

class InstFlyto2(object):
    def __init__(self):
        self.KeyName = 'flyto2'
        self.KeyValue = FlyCmdId.CMD_FLYTO2
        self.Usage = "flyto2 (waypoint) [,alt]"
        self.Description = 'flyto2 (waypoint) [,alt]: Fly to the waypoint. The flyto2 command sets the desired heading'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2 and len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstFlyto2()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type == TokenType.ABS_POS or tokens[0].Type == TokenType.REL_POS:
            # flyto (xxx, xxx)形式
            if wp_token_to_cmd_item_p1(tokens[0], cmd.Data):
                if len(tokens) == 2 and tokens[1].Type == TokenType.NUMBER:
                    f_val = float(tokens[1].Name) * 20.0
                    cmd.Data.P2 = (int)(f_val)

                # mark for fast waypoint mode
                if fly_cmp.FastWpMode:
                    cmd.Data.P1 |= 0x80
                fly_cmp.FastWpMode = False  # 仅对当前Flyto指令生效
                fly_cmp.CmdList.append(cmd)
                return True

            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        return False

    def reverse(self) -> str:
        ret = ''
        if self.Data.P1 & 0x80 > 0:
            ret = 'fastwp\r\n'
        str_wp = parse_wp_from_cmd_item2(self.Data)
        if self.Data.P2 == 0:
            ret += f'{self.KeyName} {str_wp}'
        else:
            f_alt = int(self.Data.P2) * 0.05
            ret += f"{self.KeyName} {str_wp}, {f_alt}"

        return ret

class InstFlyto3(object):
    def __init__(self):
        self.KeyName = 'flyto3'
        self.KeyValue = FlyCmdId.CMD_FLYTO3
        self.Usage = "flyto3 (waypoint) [,alt]"
        self.Description = 'flyto3 (waypoint) [,alt]: Fly to the waypoint. The flyto3 command sets the desired heading'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2 and len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstFlyto3()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type == TokenType.ABS_POS or tokens[0].Type == TokenType.REL_POS:
            # flyto (xxx, xxx)形式
            if wp_token_to_cmd_item_p1(tokens[0], cmd.Data):
                if len(tokens) == 2 and tokens[1].Type == TokenType.NUMBER:
                    f_val = float(tokens[1].Name) * (1.0/0.03)
                    cmd.Data.P2 = (int)(f_val)

                # mark for fast waypoint mode
                if fly_cmp.FastWpMode:
                    cmd.Data.P1 |= 0x80
                fly_cmp.FastWpMode = False  # 仅对当前Flyto指令生效
                fly_cmp.CmdList.append(cmd)
                return True

            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        return False

    def reverse(self) -> str:
        ret = ''
        if self.Data.P1 & 0x80 > 0:
            ret = 'fastwp\r\n'
        str_wp = parse_wp_from_cmd_item2(self.Data)
        if self.Data.P2 == 0:
            ret += f'{self.KeyName} {str_wp}'
        else:
            f_alt = int(self.Data.P2) * 0.03
            ret += f"{self.KeyName} {str_wp}, {f_alt}"

        return ret

class InstAltKind(object):
    def __init__(self):
        self.KeyName = 'altkind'
        self.KeyValue = FlyCmdId.CMD_ALTKIND
        self.Usage = "altkind [def|abs|rel|agl]"
        self.Description = 'Set Altitude kind flag'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstAltKind()
        cmd.LineNum = tokens[0].Row
        if tokens[1].Name == "def":
            cmd.Data.P1 = 0
        elif tokens[1].Name == "abs":
            cmd.Data.P1 = 1
        elif tokens[1].Name == "rel":
            cmd.Data.P1 = 2
        elif tokens[1].Name == "agl":
            cmd.Data.P1 = 3
        else:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        if 0 == self.Data.P1:
            return f"{self.KeyName} def"
        if 1 == self.Data.P1:
            return f"{self.KeyName} abs"
        if 2 == self.Data.P1:
            return f"{self.KeyName} rel"
        if 3 == self.Data.P1:
            return f"{self.KeyName} agl"
        return f"{self.KeyName} ???"


class InstCamCtrl(object):
    def __init__(self):
        self.KeyName = 'camctrl'
        self.KeyValue = FlyCmdId.CMD_CAMCTRL
        self.Usage = "camctrl [start|run|stop] [dist|time] [para]"
        self.Description = 'command to control camera by distance or time'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) > 5 or len(tokens) < 2:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        ActCamStop = 0x00
        ActCamStartByDist = 0x01
        ActCamStartByTime = 0x02
        ActCamRunByDist = 0x03

        cmd = InstCamCtrl()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove Flycmd Name

        act_code = 0xFF
        if tokens[0].Name.startswith('start'):
            act_code = ActCamStartByDist
        elif tokens[0].Name.startswith('stop'):
            act_code = ActCamStop
        elif tokens[0].Name.startswith('run'):
            act_code = ActCamRunByDist

        if act_code == 0xFF:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        if act_code == ActCamStartByDist or act_code == ActCamRunByDist:
            if len(tokens) == 1:
                # 不带任何参数的情况, camctrl [start|run] (立即拍照)
                cmd.Data.P1 = act_code
                cmd.Data.P2 = 0

            elif len(tokens) == 3 or len(tokens) == 4:
                if tokens[2].Type != TokenType.NUMBER:
                    return False

                dist_mode = tokens[1].Name.startswith('dist')
                time_mode = tokens[1].Name.startswith('time')

                if dist_mode:
                    cmd.Data.P1 = act_code
                    dist_cm = float(tokens[2].Name) * 100.0
                    if dist_cm < 100 or dist_cm > 32000:  # 无效距离参数
                        fly_cmp.ErrorMsg = 'Invalid dist param'
                        return False
                    cmd.Data.P2 = dist_cm

                if time_mode:
                    cmd.Data.P1 = ActCamStartByTime
                    tim_ms = int(tokens[2].Name)
                    if tim_ms < 100 or tim_ms > 30000:  # 无效距离参数
                        fly_cmp.ErrorMsg = 'Invalid time param'
                        return False
                    cmd.Data.P2 = tim_ms

                if len(tokens) == 4:  # 带坐标位置参数
                    pos_data = parse_abs_pos(tokens[3].Name)
                    if pos_data is not None:
                        cmd.Data.P3.s32_val = int(pos_data[0] * 10e6)
                        cmd.Data.P4.s32_val = int(pos_data[1] * 10e6)
                    else:
                        cmd.Data.P3.s32_val = 0
                        cmd.Data.P4.s32_val = 0
            else:
                return False
        elif ActCamStop == act_code:  # camctrl stop
            cmd.Data.P1 = 0
            cmd.Data.P2 = 0
            if len(tokens) == 2:  # camctrl stop 1000
                if tokens[1].Type == TokenType.NUMBER:  # 带超时参数
                    cmd.Data.P2 = int(tokens[1].Name)
                elif tokens[1].Type == TokenType.ABS_POS:  # 带坐标位置参数
                    cmd.Data.P2 = 0
                    pos_data = parse_abs_pos(tokens[1].Name)
                    if pos_data is not None:
                        cmd.Data.P3.s32_val = int(pos_data[0] * 10e6)
                        cmd.Data.P4.s32_val = int(pos_data[1] * 10e6)
                    else:
                        cmd.Data.P3.s32_val = 0
                        cmd.Data.P4.s32_val = 0
                else:
                    return False

        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        return f"{self.KeyName} ???"


class InstCircleLeft(object):
    def __init__(self):
        self.KeyName = 'circleleft'
        self.KeyValue = FlyCmdId.CMD_CIRCLELEFT
        self.Usage = "circleleft [(waypoint)] [,alt]"
        self.Description = 'Fly a circle to the right (clockwise) around the specified waypoint'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) > 4:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstCircleLeft()
        cmd.LineNum = tokens[0].Row

        if 1 == len(tokens):
            cmd.Data.P1 = ParaType.EMPTY
            cmd.Data.P2 = 0
            fly_cmp.CmdList.append(cmd)
            return True

        tokens.pop(0)  # Remove cmd Name
        if (tokens[0].Type == TokenType.ABS_POS or
                tokens[0].Type == TokenType.REL_POS):
            if not wp_token_to_cmd_item_p1(tokens[0], cmd.Data):
                fly_cmp.ErrorMsg = 'Invalid center'
                return False

            if len(tokens) == 2:
                cmd.Data.P2 = int(tokens[1].Name)

            fly_cmp.CmdList.append(cmd)
            return True

        if tokens[0].Type == TokenType.NUMBER:
            cmd.Data.P1 = ParaType.EMPTY
            cmd.Data.P2 = int(tokens[0].Name) if len(tokens) == 1 else 0
            fly_cmp.CmdList.append(cmd)
            return True

        fly_cmp.ErrorMsg = 'Invalid param'
        return False

    def reverse(self) -> str:
        if self.Data.P1 == ParaType.ABS_POS or self.Data.P1 == ParaType.REL_POS:
            strWp = parse_wp_from_cmd_item2(self.Data)
            return (
                f"{self.KeyName} {strWp}"
                if 0 == self.Data.P2
                else f"{self.KeyName} {strWp}, {self.Data.P2}"
            )

        if self.Data.P1 == ParaType.EMPTY:
            return f"{self.KeyName}" if 0 == self.Data.P2 else f"{self.KeyName} {self.Data.P2}"

        return f"{self.KeyName} ???"


class InstCircleRight(object):
    def __init__(self):
        self.KeyName = 'circleright'
        self.KeyValue = FlyCmdId.CMD_CIRCLERIGHT
        self.Usage = "circleright [(waypoint)] [,alt]"
        self.Description = 'Fly a circle to the left (anti-clockwise) around the specified waypoint'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) > 4:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstCircleRight()
        cmd.LineNum = tokens[0].Row

        if 1 == len(tokens):
            cmd.Data.P1 = ParaType.EMPTY
            cmd.Data.P2 = 0
            fly_cmp.CmdList.append(cmd)
            return True

        tokens.pop(0)  # Remove cmd Name
        if (tokens[0].Type == TokenType.ABS_POS or
                tokens[0].Type == TokenType.REL_POS):
            if not wp_token_to_cmd_item_p1(tokens[0], cmd.Data):
                fly_cmp.ErrorMsg = 'Invalid center'
                return False

            if len(tokens) == 2:
                cmd.Data.P2 = int(tokens[1].Name)

            fly_cmp.CmdList.append(cmd)
            return True

        if tokens[0].Type == TokenType.NUMBER:
            cmd.Data.P1 = ParaType.EMPTY
            cmd.Data.P2 = int(tokens[0].Name) if len(tokens) == 1 else 0
            fly_cmp.CmdList.append(cmd)
            return True

        fly_cmp.ErrorMsg = 'Invalid param'
        return False

    def reverse(self) -> str:
        if self.Data.P1 == ParaType.ABS_POS or self.Data.P1 == ParaType.REL_POS:
            strWp = parse_wp_from_cmd_item2(self.Data)
            return (
                f"{self.KeyName} {strWp}"
                if 0 == self.Data.P2
                else f"{self.KeyName} {strWp}, {self.Data.P2}"
            )

        if self.Data.P1 == ParaType.EMPTY:
            return f"{self.KeyName}" if 0 == self.Data.P2 else f"{self.KeyName} {self.Data.P2}"

        return f"{self.KeyName} ???"


class InstCircleSet(object):
    def __init__(self):
        self.KeyName = 'circleset'
        self.KeyValue = FlyCmdId.CMD_CIRCLESET
        self.Usage = "circleset [repeatNum] [radius] [targetBearing]"
        self.Description = 'Set circle control parameters'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 4:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstCircleSet()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove cmd Name

        if (tokens[0].Type == TokenType.NUMBER and
                tokens[1].Type == TokenType.NUMBER and
                tokens[2].Type == TokenType.NUMBER):
            cmd.Data.P1 = int(tokens[0].Name)
            cmd.Data.P2 = int(tokens[1].Name)
            cmd.Data.P3.u16_val = int(tokens[2].Name)
            cmd.Data.P4.u32_val = 0
            fly_cmp.CmdList.append(cmd)
            return True

        fly_cmp.ErrorMsg = 'Invalid param'
        return False

    def reverse(self) -> str:
        return f"{self.KeyName} {self.Data.P1} {self.Data.P2} {self.Data.P3.u16_val}"


class InstClimb(object):
    def __init__(self):
        self.KeyName = 'climb'
        self.KeyValue = FlyCmdId.CMD_CLIMB
        self.Usage = "climb alt [,altType]"
        self.Description = 'Initiate a climb to altitude(elevation or relative height)'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2 and len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstClimb()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove Cmd Name

        if tokens[0].Type == TokenType.NUMBER:
            cmd.Data.P3.float_val = float(tokens[0].Name)
            cmd.Data.P1 = ParaType.REL_POS
            if len(tokens) == 2 and 0 != float(tokens[1].Name):
                cmd.Data.P1 = ParaType.ABS_POS

            fly_cmp.CmdList.append(cmd)
            return True

        fly_cmp.ErrorMsg = 'Invalid param'
        return False

    def reverse(self) -> str:
        if self.Data.P1 == ParaType.ABS_POS:
            return f"{self.KeyName} {self.Data.P3.float_val:.2f},1//abs m"

        return f"{self.KeyName} {self.Data.P3.float_val:.2f}//m"


class InstDelay(object):
    def __init__(self):
        self.KeyName = 'delay'
        self.KeyValue = FlyCmdId.CMD_DELAY
        self.Usage = "delay duration"
        self.Description = 'pauses task for duration in ms. The task does not run any commands while paused'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstDelay()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type != TokenType.NUMBER:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        cmd.Data.P3.u32_val = int(tokens[0].Name)
        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        return f"{self.KeyName} {self.Data.P3.u32_val}//ms"


class InstIOCtrl(object):
    def __init__(self):
        self.KeyName = 'ioctrl'
        self.KeyValue = FlyCmdId.CMD_IOCTRL
        self.Usage = "ioctrl [set|reset|toggle] ch"
        self.Description = 'set/reset/toggle GPIO channel'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2 and len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstIOCtrl()
        tokens.pop(0)  # Remove Flycmd Name
        cmd.Data.P1 = 0xFF
        # 通道控制动作编码
        if tokens[0].Name.startswith("reset"):
            cmd.Data.P1 = 0
        if tokens[0].Name.startswith("set"):
            cmd.Data.P1 = 1
        if tokens[0].Name.startswith("toggle"):
            cmd.Data.P1 = 2
        if 0xFF == cmd.Data.P1:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        # 通道编号处理
        if tokens[1].Type != TokenType.NUMBER:
            return False
        cmd.Data.P2 = int(tokens[1].Name)
        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        if self.Data.P1 == 0:
            return f"{self.KeyName} reset {self.Data.P2}"
        if self.Data.P1 == 1:
            return f"{self.KeyName} set {self.Data.P2}"
        if self.Data.P1 == 2:
            return f"{self.KeyName} toggle {self.Data.P2}"
        return f"{self.KeyName} ???"


class InstLand(object):
    def __init__(self):
        self.KeyName = 'land'
        self.KeyValue = FlyCmdId.CMD_LAND
        self.Usage = "land [location] [,alt]"
        self.Description = 'Return to land point and do land'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) > 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        result = False
        cmd = InstLand()
        cmd.LineNum = tokens[0].Row

        if 1 == len(tokens):
            cmd.Data.P1 = ParaType.EMPTY
            cmd.Data.P2 = 0
            result = True
        else:
            tokens.pop(0)  # Remove Cmd Name
            if (tokens[0].Type == TokenType.ABS_POS
                    or tokens[0].Type == TokenType.REL_POS
                    or tokens[0].Type == TokenType.POINTER):
                result = wp_token_to_cmd_item_p1(tokens[0], cmd.Data)

        if result:
            if len(tokens) == 2 and tokens[1].Type == TokenType.NUMBER:
                cmd.Data.P2 = int(tokens[1].Name)

            fly_cmp.CmdList.append(cmd)

        return result

    def reverse(self) -> str:
        src = f"{self.KeyName} {parse_wp_from_cmd_item2(self.Data)}"
        if self.Data.P1 == 0:
            src = f"{self.KeyName}"
        if self.Data.P2 != 0:
            src = f"{self.KeyName} {parse_wp_from_cmd_item2(self.Data)}, {self.Data.P2}"
        return src


class InstPODCtrl(object):
    def __init__(self):
        self.KeyName = 'podctrl'
        self.KeyValue = FlyCmdId.CMD_PODCTRL
        self.Usage = "podctrl act para"
        self.Description = 'POD control command'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:

        if len(tokens) < 2 or len(tokens) > 4:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstPODCtrl()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove cmd Name

        # 设置动作编码
        if "snap" == tokens[0].Name:
            cmd.Data.P1 = 0
            if (len(tokens) == 3
                    and tokens[1].Type == TokenType.NUMBER
                    and tokens[2].Type == TokenType.NUMBER):
                cmd.Data.P3.u32_val = int(tokens[1].Name)
                cmd.Data.P4.u32_val = int(tokens[2].Name)
        elif "zoom" == tokens[0].Name:
            cmd.Data.P1 = 1
            if len(tokens) < 2 or tokens[1].Type != TokenType.NUMBER:
                return False
            cmd.Data.P2 = int(tokens[1].Name)

        elif "angle" == tokens[0].Name:
            cmd.Data.P1 = 2
            if len(tokens) < 3 or tokens[1].Type != TokenType.NUMBER:
                fly_cmp.ErrorMsg = "Invalid angle param"
                return False
            cmd.Data.P3.float_val = float(tokens[1].Name)
            cmd.Data.P4.float_val = float(tokens[2].Name)

        elif "record" == tokens[0].Name:
            cmd.Data.P1 = 3
            if "start" == tokens[1].Name:
                cmd.Data.P2 = 1
            elif "stop" == tokens[1].Name:
                cmd.Data.P2 = 0
            else:
                fly_cmp.ErrorMsg = "Invalid record param"
                return False

        elif "lidar" == tokens[0].Name:
            cmd.Data.P1 = 4
            if "start" == tokens[1].Name:
                cmd.Data.P2 = 1
            elif "stop" == tokens[1].Name:
                cmd.Data.P2 = 0
            else:
                fly_cmp.ErrorMsg = "Invalid lidar param"
                return False

        elif "osd" == tokens[0].Name:
            cmd.Data.P1 = 5
            if "start" == tokens[1].Name:
                cmd.Data.P2 = 1
            elif "stop" == tokens[1].Name:
                cmd.Data.P2 = 0
            else:
                fly_cmp.ErrorMsg = "Invalid OSD param"
                return False

        elif "move" == tokens[0].Name:
            cmd.Data.P1 = 6
            if "stop" == tokens[1].Name:
                cmd.Data.P2 = 0
            elif "up" == tokens[1].Name:
                cmd.Data.P2 = 1
            elif "down" == tokens[1].Name:
                cmd.Data.P2 = 2
            elif "left" == tokens[1].Name:
                cmd.Data.P2 = 3
            elif "right" == tokens[1].Name:
                cmd.Data.P2 = 4
            elif "zero" == tokens[1].Name:
                cmd.Data.P2 = 255
            else:
                fly_cmp.ErrorMsg = "Invalid move param"
                return False

        elif "videosrc" == tokens[0].Name:
            cmd.Data.P1 = 7
            if tokens[1].Type == TokenType.NUMBER:
                cmd.Data.P2 = int(tokens[1].Name)
            else:
                fly_cmp.ErrorMsg = "Invalid videosrc param"
                return False

        else:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        if self.Data.P1 == 0:
            return f"{self.KeyName} snap"

        if self.Data.P1 == 1:
            return f"{self.KeyName} zoom {self.Data.P2}"

        if self.Data.P1 == 2:
            return f"{self.KeyName} angle {self.Data.P3.float_val} {self.Data.P4.float_val}"

        if self.Data.P1 == 3:
            return (
                f"{self.KeyName} record stop"
                if self.Data.P2 == 0
                else f"{self.KeyName} record start"
            )

        if self.Data.P1 == 4:
            return (
                f"{self.KeyName} lidar stop"
                if self.Data.P2 == 0
                else f"{self.KeyName} lidar start"
            )

        if self.Data.P1 == 5:
            return (
                f"{self.KeyName} osd stop"
                if self.Data.P2 == 0
                else f"{self.KeyName} osd start"
            )

        if self.Data.P1 == 6:
            if self.Data.P2 == 0:
                return f"{self.KeyName} move stop"
            if self.Data.P2 == 1:
                return f"{self.KeyName} move up"
            if self.Data.P2 == 2:
                return f"{self.KeyName} move down"
            if self.Data.P2 == 3:
                return f"{self.KeyName} move left"
            if self.Data.P2 == 4:
                return f"{self.KeyName} move right"
            if self.Data.P2 == 255:
                return f"{self.KeyName} move zero"

            return f"{self.KeyName} move ???"

        if self.Data.P1 == 7:
            return f"{self.KeyName} videosrc {self.Data.P2}"

        return f"{self.KeyName} ???"


class InstPWMCtrl(object):
    def __init__(self):
        self.KeyName = 'pwmctrl'
        self.KeyValue = FlyCmdId.CMD_PWMCTRL
        self.Usage = "pwmctrl ch pulse"
        self.Description = 'set servo to Pulse width in us'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstPWMCtrl()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove cmd Name

        if tokens[0].Type != TokenType.NUMBER:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        if tokens[1].Type != TokenType.NUMBER:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        # 设置伺服通道
        cmd.Data.P1 = ParaType.NUMBER
        cmd.Data.P3.u32_val = int(tokens[0].Name)

        # 设置伺服脉宽
        cmd.Data.P2 = int(tokens[1].Name)
        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        if self.Data.P1 == ParaType.NUMBER:
            return f"{self.KeyName} {self.Data.P3.u32_val} {self.Data.P2}"
        return f"{self.KeyName} ???"


class InstSeederCtrl(object):
    def __init__(self):
        self.KeyName = 'seederctrl'
        self.KeyValue = FlyCmdId.CMD_SEEDERCTRL
        self.Usage = "seederctrl act param"
        self.Description = 'set Seeder control'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 3 and len(tokens) != 2:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstSeederCtrl()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove cmd Name

        # 设置Action code
        if "stop" == tokens[0].Name:
            cmd.Data.P1 = 0
        elif "start" == tokens[0].Name:
            cmd.Data.P1 = 1
        elif "run" == tokens[0].Name:
            cmd.Data.P1 = 2
            if len(tokens) != 2:
                fly_cmp.ErrorMsg = 'Invalid Usage'
                return False
            cmd.Data.P3.f32_val = float(tokens[1].Name)
        else:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        if self.Data.P1 == 0:
            return f"{self.KeyName} stop"
        elif self.Data.P1 == 1:
            return f"{self.KeyName} start"
        elif self.Data.P1 == 2:
            return f"{self.KeyName} run {self.Data.P3.f32_val}"

        return f"{self.KeyName} ???"

class InstRepeat(object):
    def __init__(self):
        self.KeyName = 'repeat'
        self.KeyValue = FlyCmdId.CMD_REPEAT
        self.Usage = "repeat –line"
        self.Description = ("This command can be used to repeat all or portions of a flight program. If line is not "
                            "specified, this command resets the command buffer to the first command.")
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        cmd = InstRepeat()
        cmd.LineNum = tokens[0].Row
        tokens.pop(0)  # Remove cmd Name
        ForeverCnt = 9999
        cmd.Data.P1 = ParaType.NUMBER
        cmd.Data.P2 = 0
        if len(tokens) == 1:
            if tokens[0].Type == TokenType.NUMBER:
                cmd.Data.P2 = int(tokens[0].Name)
            elif tokens[0].Name == "forever":
                cmd.Data.P2 = ForeverCnt
            else:
                fly_cmp.ErrorMsg = 'Invalid param'
                return False

        # 参数作用域有效性判定
        rang = abs(cmd.Data.P2)
        if 0 != cmd.Data.P2:
            if rang > len(fly_cmp.CmdList) and ForeverCnt != cmd.Data.P2:
                fly_cmp.ErrorMsg = f"Repeat parameter out range, should <{len(fly_cmp.CmdList)}."
                return False

        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        if 9999 == self.Data.P2:
            return f"{self.KeyName} forever"
        return f"{self.KeyName} {self.Data.P2}" if self.Data.P2 != 0 else f"{self.KeyName}"


class InstSetLandYaw(object):
    def __init__(self):
        self.KeyName = 'setlandyaw'
        self.KeyValue = FlyCmdId.CMD_SETLANDYAW
        self.Usage = "setlandyaw [target yaw]"
        self.Description = 'Set target yaw for land'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstSetLandYaw()
        cmd.LineNum = tokens[0].Row

        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type != TokenType.NUMBER:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        cmd.Data.P1 = 0
        cmd.Data.P2 = 0
        cmd.Data.P3.float_val = float(tokens[0].Name)
        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        return f"{self.KeyName} {self.Data.P3.float_val} //deg"


class InstSetLandAlt(object):
    def __init__(self):
        self.KeyName = 'setlandalt'
        self.KeyValue = FlyCmdId.CMD_SETLANDALT
        self.Usage = "setlandyaw [target alt] [abs|rel]"
        self.Description = 'Set target yaw for land'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstSetLandAlt()
        cmd.LineNum = tokens[0].Row

        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type != TokenType.NUMBER:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False
        if tokens[1].Name == "abs":
            cmd.Data.P1 = ParaType.ABS_POS
        elif tokens[1].Name == "rel":
            cmd.Data.P1 = ParaType.REL_POS
        else:
            return False
        cmd.Data.P2 = 0
        cmd.Data.P3.float_val = float(tokens[0].Name)
        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        if self.Data.P1 == ParaType.ABS_POS:
            return f"{self.KeyName} {self.Data.P3.float_val} abs //m"
        if self.Data.P1 == ParaType.REL_POS:
            return f"{self.KeyName} {self.Data.P3.float_val} rel //m"
        return f"{self.KeyName} {self.Data.P3.float_val} ??? //m"

class InstSetSpeed(object):
    def __init__(self):
        self.KeyName = 'setspeed'
        self.KeyValue = FlyCmdId.CMD_SETSPEED
        self.Usage = "setspeed [target speed]"
        self.Description = 'Set target speed'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstSetSpeed()
        cmd.LineNum = tokens[0].Row

        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type != TokenType.NUMBER:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        cmd.Data.P1 = 0
        cmd.Data.P2 = int(tokens[0].Name)
        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        return f"{self.KeyName} {self.Data.P2} //m/s"


class InstSetWpYaw(object):
    def __init__(self):
        self.KeyName = 'setwpyaw'
        self.KeyValue = FlyCmdId.CMD_SETWPYAW
        self.Usage = "setwpyaw [target yaw],[Mode]"
        self.Description = 'Set target yaw for land'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2 and len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstSetWpYaw()
        cmd.LineNum = tokens[0].Row

        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type != TokenType.NUMBER:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        cmd.Data.P1 = 0
        if len(tokens) == 2:  # Mode param is exist
            if tokens[1].Type != TokenType.NUMBER:
                fly_cmp.ErrorMsg = 'Invalid param'
                return False
            cmd.Data.P1 = int(tokens[1].Name)

        cmd.Data.P2 = 0
        cmd.Data.P3.float_val = float(tokens[0].Name)
        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        return f"{self.KeyName} {self.Data.P3.float_val},{self.Data.P1}//deg"


class InstTakeoff(object):
    def __init__(self):
        self.KeyName = 'takeoff'
        self.KeyValue = FlyCmdId.CMD_TAKEOFF
        self.Usage = "takeoff [alt][,altType]"
        self.Description = ("takeoff :Performs a takeoff. All .fly files must include a takeoff command, even if the "
                            "takeoff will be performed manually.")
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        cmd = InstTakeoff()
        if len(tokens) == 1:
            cmd.Data.P1 = ParaType.EMPTY
            cmd.Data.P2 = 0
        elif len(tokens) == 2:
            if tokens[1].Type != TokenType.NUMBER:
                return False
            cmd.Data.P1 = ParaType.REL_POS
            cmd.Data.P2 = int(tokens[1].Name)
            if cmd.Data.P2 > 32000 or cmd.Data.P2 < 0:
                fly_cmp.ErrorMsg = 'Parameter is outrage'
                return False
        elif len(tokens) == 3:
            if tokens[1].Type != TokenType.NUMBER:
                return False
            if tokens[2].Type != TokenType.NUMBER:
                return False

            cmd.Data.P2 = int(tokens[1].Name)
            altType = float(tokens[2].Name)
            cmd.Data.P1 = ParaType.ABS_POS if (1 == altType) else ParaType.REL_POS
        else:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        if self.Data.P1 == ParaType.EMPTY:
            return f"{self.KeyName} {self.Data.P2} //m"

        if self.Data.P1 == ParaType.REL_POS:
            return f"{self.KeyName} {self.Data.P2} //m"

        if self.Data.P1 == ParaType.ABS_POS:
            return f"{self.KeyName} {self.Data.P2},1 //m"

        return f"{self.KeyName} ???"


class InstWaitClimb(object):
    def __init__(self):
        self.KeyName = 'waitclimb'
        self.KeyValue = FlyCmdId.CMD_WAITCLIMB
        self.Usage = "waitclimb alt"
        self.Description = ("Waits until a climb, initialized by the climb command, has reached the altitude specified "
                            "in the altitude parameter.")
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2 and len(tokens) != 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstWaitClimb()
        cmd.LineNum = tokens[0].Row

        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type != TokenType.NUMBER:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        cmd.Data.P1 = ParaType.REL_POS
        cmd.Data.P2 = 0
        cmd.Data.P3.float_val = float(tokens[0].Name)
        if len(tokens) == 2 and 0 != int(tokens[1].Name):
            cmd.Data.P1 = ParaType.ABS_POS

        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        if self.Data.P1 == ParaType.ABS_POS:
            return f"{self.KeyName} {self.Data.P3.float_val}, 1// abs m"

        return f"{self.KeyName} {self.Data.P3.float_val}//m"


class InstWaitFmt(object):
    def __init__(self):
        self.KeyName = 'waitfmt'
        self.KeyValue = FlyCmdId.CMD_WAITFMT
        self.Usage = "waitfmt"
        self.Description = 'Waits until all drone in formation is ready'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 1:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstWaitFmt()
        cmd.LineNum = tokens[0].Row
        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        return f"{self.KeyName}"


class InstWaitSpin(object):
    def __init__(self):
        self.KeyName = 'waitspin'
        self.KeyValue = FlyCmdId.CMD_WAITSPIN
        self.Usage = "waitspin yaw_angle"
        self.Description = 'Waits until reached the yaw specified in the yaw_angle parameter'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) != 2:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstWaitSpin()
        cmd.LineNum = tokens[0].Row

        tokens.pop(0)  # Remove Cmd Name
        if tokens[0].Type != TokenType.NUMBER:
            fly_cmp.ErrorMsg = 'Invalid param'
            return False

        cmd.Data.P1 = 0
        cmd.Data.P2 = 0
        cmd.Data.P3.float_val = float(tokens[0].Name)
        fly_cmp.CmdList.append(cmd)
        return True

    def reverse(self) -> str:
        return f"{self.KeyName} {self.Data.P2}//deg"


class InstHover(object):
    def __init__(self):
        self.KeyName = 'hover'
        self.KeyValue = FlyCmdId.CMD_HOVER
        self.Usage = "hover [(hoverpoint)] [,alt]"
        self.Description = 'hover at specail location'
        self.Data = FlyCmdItem(self.KeyValue)

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        if len(tokens) > 3:
            fly_cmp.ErrorMsg = 'Invalid Usage'
            return False

        cmd = InstHover()
        cmd.LineNum = tokens[0].Row

        tokens.pop(0)  # Remove Cmd Name
        if len(tokens) == 0:
            cmd.Data.P1 = ParaType.EMPTY
            cmd.Data.P2 = 0
            fly_cmp.CmdList.append(cmd)
            return True

        if tokens[0].Type == TokenType.ABS_POS or tokens[0].Type == TokenType.REL_POS:
            result = wp_token_to_cmd_item_p1(tokens[0], cmd)
            if result and len(tokens) == 2 and tokens[1].Type == TokenType.NUMBER:
                cmd.P2 = int(tokens[1].Name)
                fly_cmp.CmdList.append(cmd)
                return True

        if tokens[0].Type == TokenType.NUMBER:
            if len(tokens) == 1:
                cmd.P1 = ParaType.NUMBER
                cmd.P2 = int(tokens[0].Name)
                fly_cmp.CmdList.append(cmd)
                return True

        return False

    def reverse(self) -> str:
        return f"{self.KeyName} {self.Data.P2}//deg"


class PseudoFastWp(object):
    def __init__(self):
        self.KeyName = 'fastwp'
        self.KeyValue = 0xFD
        self.Description = 'Marks the Next flyto cmd use fast waypoint mode'
        self.IsPseudo = True

    @staticmethod
    def process(fly_cmp, tokens: list) -> bool:
        fly_cmp.FastWpMode = True
        return True

#---------------------------------------------------------
# 工具类函数
#---------------------------------------------------------
def parse_abs_pos(str_data):
    """
    从字符串中解析出绝对位置数据, 解析失败返回None
    """
    result = [0.0, 0.0]
    # 去除"()"
    str_data = str_data.strip()[1:-1]
    # 解析数据
    str_pos = str_data.split(',')
    str_pos[0] = str_pos[0].strip()
    result[0] = float(str_pos[0][0:-1])

    str_pos[1] = str_pos[1].strip()
    result[1] = float(str_pos[1][0:-1])

    if str_pos[0].endswith('w') or str_pos[0].endswith('W'):
        result[0] = -result[0]

    if str_pos[1].endswith("s") or str_pos[1].endswith("S"):
        result[1] = -result[1]

    return result


def parse_res_pos(str_data):
    """
    从字符串中解析出相对位置数据, 解析失败返回None
    """
    str_data = str_data.strip()
    result = [0.0, 0.0]
    # 去除"()"
    str_data = str_data[1:-1]
    # 解析数据
    str_pos = str_data.split(',')
    result[0] = float(str_pos[0].strip())
    result[1] = float(str_pos[1].strip())
    return result


def parse_wp_from_cmd_item1(p3:AnyValue, p4:AnyValue):
    """
    从命令中解析位置数据的字符串表达方式
    """
    ret = '('
    lng = round(p3.s32_val / 10e6, 7)
    lat = round(p4.s32_val / 10e6, 7)
    ret += f'{-lng}W,' if (lng < 0) else f'{lng}E,'
    ret += f'{-lat}S)' if (lat < 0) else f'{lat}N)'
    return ret


def parse_wp_from_cmd_item2(cmd:FlyCmdItem):
    """
    从命令中解析位置数据的字符串表达方式
    """
    ret = '(???, ???)'
    pt = ParaType(cmd.P1 & 0x0F)
    if ParaType.REL_POS == pt:
        f3 = round(cmd.P3.float_val, 3)
        f4 = round(cmd.P4.float_val, 3)
        ret = f'({f3}, {f4})'
    if ParaType.ABS_POS == pt:
        lng = cmd.P3.s32_val / 10e6
        lat = cmd.P4.s32_val / 10e6
        ret = '('
        ret += f'{-lng:.7f}W,' if (lng < 0) else f'{lng:.7f}E,'
        ret += f'{-lat:.7f}S)' if (lat < 0) else f'{lat:.7f}N)'
    return ret


def is_nav_cmd(cmd) -> bool:
    """
    判断是否为导航指令（参数可能带坐标信息）
    """
    return cmd.KeyValue == FlyCmdId.CMD_FLYTO or \
        cmd.KeyValue == FlyCmdId.CMD_LAND or \
        cmd.KeyValue == FlyCmdId.CMD_CIRCLELEFT or \
        cmd.KeyValue == FlyCmdId.CMD_CIRCLERIGHT


def is_end_cmd(cmd) -> bool:
    """
    判断该命令是否为结束语句
    """
    return cmd.KeyValue == FlyCmdId.CMD_REPEAT or \
        cmd.KeyValue == FlyCmdId.CMD_LAND

def wp_token_to_cmd_item_p1(token: FlyToken, item:FlyCmdItem) -> bool:
    """
    将词元转换成对应的命令参数1中的数值
    """
    if token.Type == TokenType.REL_POS:
        pos_data = parse_res_pos(token.Name)
        if pos_data is None:
            return False
        item.P1 = ParaType.REL_POS
        item.P3.float_val = pos_data[0]
        item.P4.float_val = pos_data[1]
        return True

    if token.Type == TokenType.ABS_POS:
        pos_data = parse_abs_pos(token.Name)
        if pos_data is None:
            return False
        item.P1 = ParaType.ABS_POS
        item.P3.s32_val = int(pos_data[0] * 10e6)
        item.P4.s32_val = int(pos_data[1] * 10e6)
        return True
    return False
