# -*- coding: utf-8 -*-

class RelPos(object):
    def __init__(self, x: float, y: float, z=0.0):
        self.X = x
        self.Y = y
        self.Z = z
