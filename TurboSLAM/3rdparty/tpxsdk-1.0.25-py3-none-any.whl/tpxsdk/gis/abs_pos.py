# -*- coding: utf-8 -*-
import math
from enum import IntEnum
from tpxsdk.share.data_utils import *


class AbsPos(object):
    def __init__(self, lat, lon, alt=0.0):
        self.Lat = lat
        self.Lng = lon
        self.Alt = alt

    def bearing(self, target) -> float:
        lat_now_rad = deg2rad(self.Lat)
        lon_now_rad = deg2rad(self.Lng)

        lat_next_rad = deg2rad(target.Lat)
        lon_next_rad = deg2rad(target.Lng)

        d_lon = lon_next_rad - lon_now_rad

        # conscious mix of double and float trig function to maximize speed and efficiency */
        theta = math.atan2(math.sin(d_lon) * math.cos(lat_next_rad), math.cos(lat_now_rad) * math.sin(lat_next_rad) - math.sin(lat_now_rad) * math.cos(lat_next_rad) * math.cos(d_lon))
        return wrap_360(rad2deg(theta))


class AbsPosFormat(IntEnum):
    """
    绝对位置格式
    """
    Degree = 0  # 度格式
    DegMin = 1  # 度分格式
    DegMinSec = 2  # 度分秒格式
