﻿# -*- coding: utf-8 -*-
# 地理信息工具类
from tpxsdk.gis.abs_pos import AbsPos
from tpxsdk.share.data_utils import *


class GeoUtils(object):
    def __init__(self):
        pass

    @staticmethod
    def new_pos(x, y, bearing, dist):
        """
        计算新点
        """
        deg_n = 90 - bearing
        if deg_n < 0:
            deg_n += 360
        rad_n = deg2rad(deg_n)
        x += dist * math.cos(rad_n)
        y += dist * math.sin(rad_n)
        return [x, y]

    @staticmethod
    def get_distance(p1: AbsPos, p2: AbsPos) -> float:
        """
        计算两点之间距离
        """
        d = p1.Lat * 0.017453292519943295
        num2 = p1.Lng * 0.017453292519943295
        num3 = p2.Lat * 0.017453292519943295
        num4 = p2.Lng * 0.017453292519943295
        num5 = num4 - num2
        num6 = num3 - d
        num7 = math.pow(math.sin(num6 / 2.0), 2.0) + math.cos(d) * math.cos(num3) * math.pow(math.sin(num5 / 2.0), 2.0)
        num8 = 2.0 * math.atan2(math.sqrt(num7), math.sqrt(1.0 - num7))
        return 6371 * num8 * 1000.0
    
    @staticmethod
    def get_distance_3d(p1: AbsPos, p2: AbsPos) -> float:
        """
        计算两点之间距离(三维)
        """
        hdis = GeoUtils.get_distance(p1, p2)
        return math.sqrt((p2.Alt - p1.Alt)*(p2.Alt - p1.Alt) + (hdis * hdis))

    @staticmethod
    def add_angle(angle, degrees) -> float:
        """
        Add an angle while normalizing output in the range 0...360
        """
        angle += degrees
        angle %= 360.0
        return angle

    @staticmethod
    def dist_to_line(loc: AbsPos, p1: AbsPos, p2: AbsPos) -> float:
        """
        计算点loc到P1-P2构成的线段垂直距离
        """
        dist_to_end = GeoUtils.get_distance(loc, p2)
        # Return error if arguments are bad */
        if dist_to_end < 0.001:
            return 0
        bearing_end = deg2rad(loc.bearing(p2))
        bearing_track = deg2rad(p1.bearing(p2))
        bearing_diff = wrap_pi(bearing_track - bearing_end)
        sin_bearing_diff = math.sin(bearing_diff)
        return math.fabs(dist_to_end * sin_bearing_diff)

    @staticmethod
    def __limit(val, min_val, max_val):
        if val < min_val:
            return min_val
        if val > max_val:
            return max_val
        return val

    @staticmethod
    def geo_project(lat_0, lon_0, lat, lon):
        const_radius_of_earth = 6371000.0
        ref_lat = math.radians(lat_0)
        ref_lon = math.radians(lon_0)
        ref_sin_lat = math.sin(ref_lat)
        ref_cos_lat = math.cos(ref_lat)

        lat_rad = math.radians(lat)
        lon_rad = math.radians(lon)

        sin_lat = math.sin(lat_rad)
        cos_lat = math.cos(lat_rad)

        cos_d_lon = math.cos(lon_rad - ref_lon)

        arg = GeoUtils.__limit(ref_sin_lat * sin_lat + ref_cos_lat * cos_lat * cos_d_lon, -1.0, 1.0)
        c = math.acos(arg)

        k = 1.0

        if math.fabs(c) > 0.0:
            k = (c / math.sin(c))

        x = float(k * (ref_cos_lat * sin_lat - ref_sin_lat * cos_lat * cos_d_lon) * const_radius_of_earth)
        y = float(k * cos_lat * math.sin(lon_rad - ref_lon) * const_radius_of_earth)
        return [x, y]

    @staticmethod
    def geo_reproject(lat_0, lon_0, x, y):
        const_radius_of_earth = 6371000.0
        ref_lat = math.radians(lat_0)
        ref_lon = math.radians(lon_0)
        ref_sin_lat = math.sin(ref_lat)
        ref_cos_lat = math.cos(ref_lat)

        x_rad = x / const_radius_of_earth
        y_rad = y / const_radius_of_earth
        c = math.sqrt(x_rad * x_rad + y_rad * y_rad)

        if math.fabs(c) > 0.0:
            sin_c = math.sin(c)
            cos_c = math.cos(c)

            lat_rad = math.asin(cos_c * ref_sin_lat + (x_rad * sin_c * ref_cos_lat) / c)
            lon_rad = (ref_lon + math.atan2(y_rad * sin_c, c * ref_cos_lat * cos_c - x_rad * ref_sin_lat * sin_c))
            lat = math.degrees(lat_rad)
            lon = math.degrees(lon_rad)
            return [lat, lon]

        lat = math.degrees(ref_lat)
        lon = math.degrees(ref_lon)
        return [lat, lon]
