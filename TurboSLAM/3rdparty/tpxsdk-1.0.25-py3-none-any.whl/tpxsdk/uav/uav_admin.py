import os
import logging
import datetime
from tpxsdk.mission.fly_compiler import FlyCompiler
from tpxsdk.tplink import link_utils
from tpxsdk.tplink import link_def
from tpxsdk.tplink.rsp_code import RspCode
from tpxsdk.uav.udev_type import UDevType
from tpxsdk.uobject.uobj_admin import UObjAdmin
from tpxsdk.uobject.uobj_meta import UObjMeta, MetaDataType


class UavAdmin(object):
    def __init__(self):
        self.Items = []  # UAV集合只读列表
        self.CurrUAV = None  # 当前被选中的UAV对象,任何情况下仅仅只能选择一个
        self.PrevUAV = None  # 前一个被选中的UAV对象

    def add(self, item):
        # 查重处理
        self.Items.append(item)
        if self.CurrUAV is None:
            self.CurrUAV = item

    def clear(self):
        self.Items.clear()

    def is_ready(self, uav):
        """
        检查当前UAV是否可进行通讯交互
        """
        if uav is None:
            uav = self.CurrUAV
        if uav is None or uav.Link is None:
            return False
        return uav.Link.is_opened

    def read_uobj_meta(self, meta_path=None, uav=None):
        """
        读取当前UObjMeta信息
        """
        if not self.is_ready(uav):
            return False
        if uav is None:
            uav = self.CurrUAV

        ret = uav.Link.do_cmd_get_uobj_meta(link_def.UObjMetaSubCmd.SIG)

        if ret != RspCode.RSP_OK:
            logging.error(f"RspCode={ret}")
            return False

        signature = link_utils.gen_uint32(uav.Link.RspData)
        dev_type = UDevType(uav.Link.RspData[4])
        logging.info(f'Sig={signature} DevType={dev_type.name}')

        if meta_path is None:
            usr_root = os.path.expanduser('~')
        else:
            usr_root = meta_path
        # 检测本地是否有缓存
        meta_fn = f'{usr_root}/UObjMeta/{signature:X}-{dev_type.name}.json'
        uav.Admin = UObjAdmin()
        if os.path.exists(meta_fn):
            if uav.Admin.Signature != signature:
                uav.Admin.Signature = signature
                uav.Admin.DevType = dev_type
                if uav.Admin.load_meta(meta_fn):
                    logging.info(f'Load meta file {meta_fn} OK')
                    return True
        admin = UObjAdmin()
        admin.Signature = signature
        admin.DevType = dev_type

        # 读取Class Meta
        ret = uav.Link.do_cmd_get_uobj_meta(link_def.UObjMetaSubCmd.CLS, [0])
        if ret != RspCode.RSP_OK:
            logging.error(f"RspCode={ret}")
            return False

        index = 0
        total_cnt = uav.Link.RspData[index]
        index += 1
        meta = UObjMeta()
        meta.TypeId = uav.Link.RspData[index]
        index += 1
        meta.TypeSz = uav.Link.RspData[index]
        index += 1
        meta.InstCnt = link_utils.gen_word(uav.Link.RspData[index + 0], uav.Link.RspData[index + 1])
        index += 2
        meta.IsSetting = uav.Link.RspData[index] != 0
        index += 1
        meta.MemCnt = uav.Link.RspData[index]
        index += 1
        meta.TypeName = link_utils.decode(uav.Link.RspData, index)
        admin.MetaList.append(meta)

        for i in range(total_cnt):
            if 0 == i:
                continue
            ret = uav.Link.do_cmd_get_uobj_meta(link_def.UObjMetaSubCmd.CLS, [i])
            if ret is not RspCode.RSP_OK:
                logging.error(f"RspCode={ret}")
                return False
            index = 0
            total_cnt = uav.Link.RspData[index]
            index += 1
            meta = UObjMeta()
            meta.TypeId = uav.Link.RspData[index]
            index += 1
            meta.TypeSz = uav.Link.RspData[index]
            index += 1
            meta.InstCnt = link_utils.gen_word(uav.Link.RspData[index + 0], uav.Link.RspData[index + 1])
            index += 2
            meta.IsSetting = uav.Link.RspData[index] != 0
            index += 1
            meta.MemCnt = uav.Link.RspData[index]
            index += 1
            meta.TypeName = link_utils.decode(uav.Link.RspData, index)
            admin.MetaList.append(meta)
            logging.info(f'Get {meta.TypeName} class meta...{i * 100 / total_cnt:.2f}%')

        # 读取Member Meta
        for i in range(len(admin.MetaList)):
            meta = admin.MetaList[i]
            # Member ID 从1开始,0代表整个UOBJ对象
            for j in range(meta.MemCnt):
                ret = uav.Link.do_cmd_get_uobj_meta(link_def.UObjMetaSubCmd.MEM, [meta.TypeId, j + 1])
                # 检查回复数据有效性
                if ret != RspCode.RSP_OK:
                    logging.error(f"RspCode={ret}")
                    return False
                if meta.TypeId != uav.Link.RspData[0] or (j + 1) != uav.Link.RspData[1]:
                    return False
                # ---------------------------------------------------
                # 解析成员Meta数据格式：
                # MemType[1Byte]+MemName[变长\0结尾]+MemUnit[变长\0结尾]
                # ---------------------------------------------------
                meta.MemType.append(MetaDataType(uav.Link.RspData[2]))

                # 查找成员名称结束符
                idx = 0
                mem = uav.Link.RspData[3:]
                for b in mem:
                    if b == 0:
                        break
                    idx += 1
                meta.MemName.append(link_utils.decode(mem))
                meta.MemUnit.append(link_utils.decode(mem[idx + 1:]))
            # ---------------------------------------------------
            # logging.info(meta.MemName)
            # logging.info(meta.MemUnit)
            logging.info(f'Get {meta.TypeName} Member meta...{i * 100 / len(admin.MetaList):.2f}%')

        # All MetaData 读取完毕
        if not admin.save_meta(meta_fn):
            logging.error(f"SaveMeta fail")
            return False

        logging.info(f"Read and Save Meta OK")
        if uav.Admin.load_meta(meta_fn):
            logging.info(f'Load meta file {meta_fn} OK')

        return True

    def read_mission(self, uav=None, mis_id=0, fn=''):
        """
        执行从飞控读取任务
        """
        logging.info(f'Start Read mission, query flyadmin:')
        if not self.is_ready(uav):
            return False
        if uav is None:
            uav = self.CurrUAV
        ret = uav.Link.do_cmd_mission_query_flyadmin(mis_id)
        # ret is [count, crc]

        if ret is None:
            logging.error('Query flyadmin error')
            return False
        if ret[0] < 0:
            logging.error('Query flyadmin empty')
            return False

        logging.info(f'[Count, CRC] = {ret}')
        uav.FlyCmdList = []
        for i in range(ret[0]):
            logging.info(f"Read FlyItem[{i}]")
            cmd_item = uav.Link.do_cmd_mission_query_flyitem(mis_id, i)
            if cmd_item is None:
                logging.error(f"Read FlyItem[{i}] fail")
                return False
            uav.FlyCmdList.append(cmd_item)

        cmp = FlyCompiler()
        uav.Mission = cmp.decompile(uav.FlyCmdList)
        logging.info(f'Read Mission Success:\n===================================\n')
        logging.info(f'\n{uav.Mission}\n')
        # 将指令集保存到.fly文件中
        if len(fn) > 0 and fn.endswith('.fly'):
            with open(fn, 'w', encoding='utf-8') as f:
                f.write(uav.Mission)
            logging.info(f'Save Mission to {fn} Success')
        return True

    def write_mission(self, fn, uav=None, mis_id=1):
        """
        执行任务装载过程
        """
        if not self.is_ready(uav):
            return RspCode.RSP_ERROR
        if uav is None:
            uav = self.CurrUAV
        if not os.path.exists(fn):
            logging.error(f'无效任务文件:{fn}')
            return RspCode.RSP_ERROR

        cmp = FlyCompiler()
        # Load file and gen fly cmd list
        if not cmp.compile(fn) or len(cmp.CmdList) == 0:
            logging.error('Invalid Mission')
            return RspCode.RSP_ERROR

        crc = 0
        # 上传FlyItem列表
        for i in range(len(cmp.CmdList)):
            pct = 100 * i / len(cmp.CmdList)
            logging.info(f'Write FlyItem[{i}]...{pct:.2f}%')
            rsp_code = uav.Link.do_cmd_mission_edit_flyitem(mis_id, i, cmp.CmdList[i])
            if rsp_code != RspCode.RSP_OK:
                logging.error(f'Write FlyItem[{i}] error:{RspCode(rsp_code)}')
                return rsp_code
            data = cmp.CmdList[i].Data.get_bytes()
            crc += link_utils.crc16(data)

        # 上传FlyAdmin
        logging.info(f'Write FlyAdmin...[Cnt={len(cmp.CmdList)},CRC=0x{crc:X}]')
        rsp_code = uav.Link.do_cmd_mission_edit_flyadmin(mis_id, len(cmp.CmdList), crc)
        if rsp_code != RspCode.RSP_OK:
            logging.error(f'Write Mission Error:{rsp_code}')
            return rsp_code

        # 成功后通知加载运行Mission
        rsp_code = uav.Link.do_cmd_mission_edit_update(mis_id)
        if rsp_code != RspCode.RSP_OK:
            logging.error(f'Run Mission Error:{rsp_code}')
        else:
            logging.info(f'Write and Run Mission success')
            uav.FlyCmdList = []
            for i in range(len(cmp.CmdList)):
                uav.FlyCmdList.append(cmp.CmdList[i].Data)
            uav.Mission = cmp.decompile(uav.FlyCmdList)
        return rsp_code

    def read_setting(self, fn, meta_path=None, uav=None):
        """
        读取指定UAV对象的参数列表,并保存到文件
        """
        if not self.is_ready(uav):
            return False
        if uav is None:
            uav = self.CurrUAV
        # 读取UObject签名
        rsp_code = uav.Link.do_cmd_get_uobj_meta(link_def.UObjMetaSubCmd.SIG)
        if rsp_code != RspCode.RSP_OK or len(uav.Link.RspData) != 5:
            logging.error('Read UObjMeta SIG Error')
            return False

        sig = link_utils.gen_uint32(uav.Link.RspData)
        dev_type = UDevType(uav.Link.RspData[4])
        # 根据签名查找已经缓存的Meta模板
        setting = UObjAdmin(sig, dev_type, True)
        if len(setting.MetaList) == 0:
            # 没有对应的Meta缓存, 重新读取并保存
            if not self.read_uobj_meta(meta_path, uav):
                logging.error('Read UObjMeta Error')
                return False
            setting = UObjAdmin(sig, dev_type, True)

        # (1) 循环读取
        for i in range(len(setting.ObjList)):
            pct = 100 * i / len(setting.ObjList)
            uobj = setting.ObjList[i]
            logging.info(f'Read {uobj.friend_nm()}...{pct:.2f}%')
            rsp_obj = uav.Link.do_cmd_get_uobj(uobj)
            if rsp_obj is None:
                logging.error(f'Read {uobj.friend_nm()}...error')
                return False

        # (2) 保存到文件
        setting.save_setting(fn)
        logging.info('Read Setting Success')
        return True

    def write_setting(self, fn, uav=None):
        """
        写入配置文件到飞控
        """
        if not self.is_ready(uav):
            return False
        if uav is None:
            uav = self.CurrUAV
        # 读取UObject签名
        rsp_code = uav.Link.do_cmd_get_uobj_meta(link_def.UObjMetaSubCmd.SIG)
        if rsp_code != RspCode.RSP_OK or len(uav.Link.RspData) != 5:
            logging.error('Read UObjMeta SIG Error')
            return False

        sig = link_utils.gen_uint32(uav.Link.RspData)

        # (1) 加载参数文件
        # 设置待上传的Setting文件
        setting = UObjAdmin.load_setting(fn)
        if setting is None:
            logging.error('Invalid Setting File')
            return False

        if setting.Signature != sig:
            logging.error('Invalid Setting Signature')
            return False

        # (2) 循环写入
        for i in range(len(setting.ObjList)):
            pct = 100 * i / len(setting.ObjList)
            uobj = setting.ObjList[i]
            if not uobj.IsSetting:
                continue
            logging.info(f'Write {uobj.friend_nm()}...{pct:.2f}%')
            rsp_code = uav.Link.do_cmd_set_uobj(uobj)
            if rsp_code != RspCode.RSP_OK:
                logging.error(f'Write {uobj.friend_nm()} Error: {rsp_code} ')
                return False

        # (3) 发送保存指令
        rsp_code = uav.Link.do_cmd_save_setting()
        if rsp_code != RspCode.RSP_OK:
            logging.error(f'Save Setting Error:{rsp_code} ')
            return False
        logging.info('Write SettingFile Success')

        return True

    def read_uobjects(self, uobjs: list, uav=None):
        """
        读取多个UObject对象数据
        """
        if not self.is_ready(uav):
            return False
        if uav is None:
            uav = self.CurrUAV
        # 循环读取
        for i in range(len(uobjs)):
            pct = 100 * i / len(uobjs)
            logging.info(f'Read {uobjs[i]}...{pct}%')

            rsp_obj = uav.Link.do_cmd_get_uobj(uobjs[i])
            if rsp_obj is None:
                logging.error(f'Read {uobjs[i]} Error')
                return False

            uav.Admin.update_uobj(rsp_obj)

        logging.info('Read UObjects Success')
        return True

    def write_uobjects(self, uobjs: list, uav=None, save2_flash=False):
        """
        写入多个UObject对象数据
        """
        if not self.is_ready(uav):
            return False
        if uav is None:
            uav = self.CurrUAV
        # 循环写入
        for i in range(len(uobjs)):
            pct = 100 * i / len(uobjs)
            logging.info(f'Write {uobjs[i]}...{pct}%')

            rsp_code = uav.Link.do_cmd_set_uobj(uobjs[i], True, save2_flash)
            if rsp_code != RspCode.RSP_OK:
                logging.error(f"Write {uobjs[i]} Error")
                return False

        logging.info('Write UObjects Success')
        return True

    def connect(self, meta_path=None, uav=None):
        """
        执行联机过程
        """
        if not self.is_ready(uav):
            return False
        if uav is None:
            uav = self.CurrUAV

        # 确保UObjAdmin与飞控一致
        if uav.Admin is None:
            logging.info('Read UObjMeta ...')
            ret = self.read_uobj_meta(meta_path, uav)
            if not ret:
                logging.error('Read UObjMeta Error')
                return False

        if uav.Admin is None:
            logging.error('Lost UObjAdmin data')
            return False

        lnk = uav.Link
        lnk.RspTimeOut = 2000

        # 启动联机过程
        # Step0 Read UObjFirmware
        logging.info('Read UObjFirmware ...')
        uobj = uav.Admin.get_uobj_by_str('Firmware')
        uobj = lnk.do_cmd_get_uobj(uobj)
        if uobj is None:
            logging.error('Read UObjFirmware fail')
            return False
        ts = uobj.mem_value('BuildTime')
        dt = datetime.datetime.fromtimestamp(ts)
        logging.info(f'构建时间:{dt}')

        # Step1 Read XXXX
        uav.IsConnected = True
        logging.info(f'{uav.dev_type}  connect success')

        # Step2 Read Home Location
        uobj = uav.Admin.get_uobj_by_str('HomeLoc')
        uobj = uav.Link.do_cmd_get_uobj(uobj)
        if uobj is None:
            logging.error('Read UObjHomeLoc fail')
            return False

        # FIXME: Home点可能还未就绪
        uav.HomeLat = float(uobj[0]) / 1e7
        uav.HomeLng = float(uobj[1]) / 1e7
        uav.HomeAlt = float(uobj[2])
        return True

    def disconnect(self, uav=None):
        """
        执行断开联机
        """
        if not self.is_ready(uav):
            return False
        if uav is None:
            uav = self.CurrUAV
        # 重置相关属性
        uav.CmdStep = -1
        uav.IsReady = False
        uav.IsVNSRdy = False
        uav.IsVNSUsed = False
        uav.IsAvoiding = False
        uav.IsConnected = False
        uav.ReCnntCount = 0
        uav.HomeLoc = None
        # 关闭链路以及检测
        uav.Link.close()
