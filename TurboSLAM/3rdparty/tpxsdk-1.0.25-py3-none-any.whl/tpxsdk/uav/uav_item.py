import logging
import time
from tpxsdk.gis.abs_pos import AbsPos
from tpxsdk.gis.geo_utils import GeoUtils
from tpxsdk.tplink.tplink import TPLink
from tpxsdk.tplink.telemetry import *
from tpxsdk.tplink.link_utils import *
from tpxsdk.uav.udev_type import UDevType

# 描述飞机对象类
class UavItem(object):
    @property
    def dev_type(self) -> UDevType:
        if self.Admin is not None:
            return self.Admin.DevType
        return UDevType.UNKNOWN

    def __init__(self, link: TPLink):
        self.Name = ''  # 对象名称
        self.Link = link  # 数据链对象
        link.Owner = self
        self.IsConnected = False  # 联机状态指示
        self.UID = 0  # 设备硬件唯一标识编码
        self.DevAddr = 255  # 设备地址, 可静态设置也可动态分配
        self.Admin = None  # UObjAdmin 属性(与UAV Type相关)
        self.TlmTxt = ''  # 遥测字符串
        self.TlmCode = 65535

        #region 姿态航向
        self.Roll = 0.0  # 滚转角 deg
        self.Pitch = 0.0  # 俯仰角 deg
        self.Yaw = 0.0  # 偏航角 deg (机头指向)
        self.Course = 0.0  # 航迹角 deg (运动方向)
        #endregion

        #region Home点位置
        self.Lat = 0.0  # 当前纬度 deg
        self.Lng = 0.0  # 当前经度 deg
        self.HomeLat = 0.0  # HOME点 纬度 deg
        self.HomeLng = 0.0  # HOME点 经度 deg
        self.HomeAlt = 0.0  # HOME点 高度 m
        #endregion

        #region 高度信息
        self.Alt = 0.0  # 相对高度 meter(相对Home点)
        self.AGL = 0.0  # 对地高度 meter
        self.GPSAlt = 0.0  # GPS高度  meter
        self.BaroAlt = 0.0  # 气压高度 meter
        #endregion

        #region 吊舱信息
        self.GimbalRoll = 0  # Gimbal ENC roll angle in deg
        self.GimbalPitch = 0  # Gimbal ENC pitch angle in deg
        self.GimbalYaw = 0  # Gimbal ENC yaw angle in deg
        self.GimbalDist = 0  # 激光测距 距离(米)
        self.GimbalObjLng = 0  # 目标指示 纬度
        self.GimbalObjLat = 0  # 目标指示 精度
        self.GimbalZoomLevel = 0  # 变倍倍数
        #endregion

        #region 系统状态
        self.IsReady = False  # 飞控是否就绪
        self.IsOffGnd = False  # 是否离地
        self.IsLocked = False  # 执行器是否锁定
        self.IsVibeWarn = False  # 振动是否告警
        self.IsLogOk = False  # 日志系统是否正常
        self.IsBatFail = False  # 电池低电压标志
        self.IsAvoiding = False  # 是否正在进行避障处理
        self.IsVNSUsed = False  # VNS是否启用
        self.IsVNSRdy = False  # VNS是否就绪
        self.Temp = 0.0
        #endregion

        #region 电池信息
        self.Bat1Volt = 0
        self.Bat2Volt = 0

        self.BMS1_Volt = 0.0
        self.BMS1_Curr = 0.0
        self.BMS1_Temp = 0
        self.BMS1_Pct  = 0.0 # 剩余电量%
        self.BMS1_Flags= 0

        self.BMS2_Volt = 0.0
        self.BMS2_Curr = 0.0
        self.BMS2_Temp = 0
        self.BMS2_Pct  = 0.0 # 剩余电量%
        self.BMS2_Flags= 0
        #endregion

        #region 控制信息
        self.FlightMode = 0  # 当前飞行主模式
        self.FlightStage = 0  # 当前飞行子模式
        self.NavRoll = 0.0  # 目标滚转角,单位度
        self.NavPitch = 0.0  # 目标俯仰角,单位度
        self.NavYaw = 0.0  # 目标航向角,单位度
        self.NavCourse = 0.0  # 目标航迹角,单位度
        self.NavAlt = 0.0  # 目标高度,单位米
        self.NavSpd = 0.0  # 目标速度,单位m/s
        self.ClimbState = 0.0  # 爬升状态标记:爬升/平飞/下降
        self.AltDot = 0.0  # 高度变化速率,m/s [升降速率/垂向速度]
        self.Speed = 0.0  # 当前飞行速度,m/s
        #endregion

        #region 舵机系统
        self.Aileron = 0  #
        self.Elevator = 0  #
        self.Rudder = 0  #
        self.Throttle = 0  #
        self.Flap = 0  #
        self.Servo = []  #
        #endregion

        #region 遥控信息
        self.RCRoll = 0  # -100~+100
        self.RCPitch = 0  # -100~+100
        self.RCYaw = 0  # -100~+100
        self.RCThr = 0  # -100~+100
        self.RCState = 0xFF  #
        #endregion

        #region 统计信息
        self.FlightTime = 0  # 当前架次飞行时间,单位秒
        self.Voyage = 0.0  # 总航程,单位米
        self.DistToHome = 0.0  # 距离HOME点长度,单位米
        self.DistToTarget = 0.0  # 距离目标点长度,单位米
        #endregion

        #region 集群信息
        self.RankNum = 255
        self.FindTarget = False
        #endregion

        #region GNSS信息
        self.GPS1PDOP = None
        self.GPS1Status = None
        self.GPS1SatCnt = None
        self.GPS2PDOP = None
        self.GPS2Status = None
        self.GPS2SatCnt = None
        self.BestGPS = None
        self.GndSpeed = None
        #endregion

        # region 风场信息
        self.WindSpd = None
        self.WindDir = None
        # endregion

        #region 任务信息
        self.CmdStep = None
        self.MisPct = 0.0 # 任务完成百分比
        self.Waypoint = -1
        self.FlyCmdList = []
        #endregion

        #region 料仓信息
        self.SeederTs = 0 # 余料信息时间戳
        self.SeederWeight = 0.0 # 余料重量kg
        self.SeederPct = 0.0 # 余料百分比
        #endregion

    #--------------------------------------------------------------------------
    # 公共成员函数
    #--------------------------------------------------------------------------

    # 打开数据链
    def open(self):
        if self.Link is None:
            self.IsConnected = False
            return False

        if self.Link.is_opened:
            self.Link._send_cmd_heart_beat()
            self.IsConnected = True
            return True

        self.IsConnected = False
        return False

    # 关闭数据链
    def close(self):
        self.IsConnected = False
        if self.Link.is_opened:
            self.Link.close()

    # 字符型遥测信息更新处理
    def on_txt_tlm_rcv_event(self, txt: str):
        if self.Link.DebugEn:
            logging.info(f'Rcv:{txt}')
        self.TlmTxt = txt

        if txt.startswith(b'[SYS]:FTIM'):
            try:
                self.FlightTime = int(txt[10:])
                logging.info(f'FlightTime:{self.FlightTime} sec')
            except Exception as e:
                logging.error(f'FlightTime parse fail:{e}')

        if txt.startswith(b'[MIS]:Pct'): 
            # [MIS]:Pct %.1f, WP %d
            sub_str = txt.decode('utf-8')[6:]
            segs = sub_str.split(',')
            try:
                if len(segs) >= 1:
                    segs[0] = segs[0].strip()
                    if segs[0].startswith('Pct'):
                        self.MisPct = float(segs[0][4:])
                if len(segs) >= 2:
                    segs[1] = segs[1].strip()
                    if segs[1].startswith('WP'):
                        self.Waypoint = int(segs[1][3:])
                logging.info(f'MisPct:{self.MisPct} %, Waypoint:{self.Waypoint}')
            except Exception as e:
                logging.error(f'MisPct parse fail:{e}')

        if txt.startswith(b'[BMS]:'):
            # [BMS]:ID,Volt,Curr,Pct,Temp,Flags
            sub_str = txt.decode('utf-8')[6:]
            segs = sub_str.split(',')
            if len(segs) == 6:
                try:
                    bms_id = int(segs[0])
                    if bms_id == 0:
                        self.BMS1_Volt  = float(segs[1])
                        self.BMS1_Curr  = float(segs[2])
                        self.BMS1_Pct   = int(segs[3])
                        self.BMS2_Temp  = float(segs[4])
                        self.BMS1_Flags = float(segs[5])
                    else:
                        self.BMS2_Volt  = float(segs[1])
                        self.BMS2_Curr  = float(segs[2])
                        self.BMS2_Pct   = int(segs[3])
                        self.BMS2_Temp  = float(segs[4])
                        self.BMS2_Flags = float(segs[5])
                    logging.info(f'BMS-{segs[0]}:Parse OK')
                except Exception as e:
                    logging.error(f'BMS Parse fail:{e}')
        
        if txt.startswith(b'[SEEDER]:'):
            # [SEEDER]:%.2f %.2f %.2f %d %d
            # weight,pct,rpm,Seeder_GetonlineFlags(),Seeder_GetErrorFlags())
            sub_str = txt.decode('utf-8')[9:]
            segs = sub_str.split(' ')
            if len(segs) == 5:
                try:
                    self.SeederTs = int(time.time())
                    self.SeederWeight = float(segs[0])
                    self.SeederPct = float(segs[1])
                    logging.info(f'SEEDER: {self.SeederWeight} kg, {self.SeederPct} %')
                except Exception as e:
                    logging.error(f'SEEDER Parse fail:{e}')

    def on_code_tlm_rcv_event(self, code: int):
        if self.Link.DebugEn:
            logging.info(f'Rcv: RSP Code{code}')

    # 标准遥测信息更新处理
    def on_std_tlm_rcv_event(self, tlm):
        self.Roll = tlm.Roll * 0.01
        self.Pitch = tlm.Pitch * 0.01
        self.Lat = tlm.Lat * 1e-7
        self.Lng = tlm.Lng * 1e-7

        if isinstance(tlm, StdTlm0):
            self.Speed = tlm.Speed * 0.01
            self.NavSpd = tlm.TargetSpd * 0.01
            self.RCState = tlm.RCState
            self.FlightMode = tlm.FlightMode >> 4
            self.FlightStage = tlm.FlightMode & 0x0F
            self.BaroAlt = tlm.BaroAlt * 0.01
            self.AGL = tlm.AGL * 0.01  # 转换为m
            self.Bat1Volt = tlm.Volt1 * 0.01  # 电池电压[V]
            self.Bat2Volt = tlm.Volt2 * 0.01  # 电池电压[V]

        elif isinstance(tlm, StdTlm1):
            self.BestGPS = tlm.BestGPS
            self.GPS1SatCnt = tlm.GPS1SatNum
            self.GPS1Status = tlm.GPS1Status
            self.GPS1PDOP = tlm.GPS1DOP * 0.01

            self.GPS2SatCnt = tlm.GPS2SatNum
            self.GPS2Status = tlm.GPS2Status
            self.GPS2PDOP = tlm.GPS2DOP * 0.01

            self.GndSpeed = tlm.GndSpd * 0.01  # 地速:m/s
            self.GPSAlt = tlm.GPSAlt * 0.01  # 海拔:meter
            self.WindDir = tlm.WindDir * 360.0 / 256.0  # 风向:0~360°
            self.WindSpd = tlm.WindSpd * 0.01  # 风速:m/s

            # 计算距离HOME点的长度
            if self.HomeLat != 0 and self.HomeLng != 0:
                self.DistToHome = GeoUtils.get_distance_3d(AbsPos(self.Lat, self.Lng, self.GPSAlt), AbsPos(self.HomeLat, self.HomeLng, self.HomeAlt))

        elif isinstance(tlm, StdTlm2):
            # 伺服输出, 范围 0~200,转换为 1000~2000 us
            self.Servo = [
                1000 + 5 * tlm.SRV1,
                1000 + 5 * tlm.SRV2,
                1000 + 5 * tlm.SRV3,
                1000 + 5 * tlm.SRV4,
                1000 + 5 * tlm.SRV5,
                1000 + 5 * tlm.SRV6,
                1000 + 5 * tlm.SRV7,
                1000 + 5 * tlm.SRV8
            ]

            # RC遥控器输出, 范围 -100~100
            self.RCRoll = tlm.RCR
            self.RCPitch = tlm.RCP
            self.RCYaw = tlm.RCY
            self.RCThr = tlm.RCT

        elif isinstance(tlm, StdTlm3):
            self.Yaw = tlm.Yaw * 0.01
            self.NavYaw = tlm.TargetYaw * 0.01
            self.Course = tlm.Hdg * 0.01
            self.NavCourse = tlm.TargetHdg * 0.01
            self.NavAlt = tlm.TargetAlt * 0.01
            self.Aileron = tlm.Aileron
            self.Elevator = tlm.Elevator
            self.Rudder = tlm.Rudder
            self.Throttle = tlm.Throttle
            self.CmdStep = tlm.CmdStep

        elif isinstance(tlm, StdTlm4):
            self.NavPitch = 0.01 * tlm.TargetPitch
            self.NavRoll = tlm.TargetRoll * 0.01
            self.Alt = tlm.Alt * 0.01
            self.AltDot = tlm.AltDot * 0.01
            self.Temp = tlm.Temp
            self.ClimbState = tlm.ClimbState
            self.Voyage = tlm.Voyage  # 总航程

            # 状态标记位
            self.IsReady = bit_test(tlm.Flags, 0)
            self.IsOffGnd = bit_test(tlm.Flags, 1)
            self.IsLocked = bit_test(tlm.Flags, 2)
            self.IsVibeWarn = bit_test(tlm.Flags, 3)
            self.IsLogOk = bit_test(tlm.Flags, 4)
            self.IsBatFail = bit_test(tlm.Flags, 5)
            self.IsAvoiding = bit_test(tlm.Flags, 6)
            self.IsVNSUsed = bit_test(tlm.Flags, 7)
            self.IsVNSRdy = bit_test(tlm.Flags, 8)

        # debugging information
        #logging.info (f'{self.Roll:.2f} {self.Pitch:.2f} {self.Yaw:.2f} {self.Lat:.6f} {self.Lng:.6f}')

    # 吊舱遥测信息更新处理
    def on_gimbal_tlm_rcv_event(self, gimbal):
        if isinstance(gimbal, GimbalTlm):
            self.GimbalObjLng = gimbal.Lng * 1e-7  # Trace Object latitude  ,1e7*deg
            self.GimbalObjLat = gimbal.Lat * 1e-7  # Trace Object longitude ,1e7*deg
            self.GimbalRoll = gimbal.Roll * 0.01
            self.GimbalPitch = gimbal.Pitch * 0.01
            self.GimbalYaw = gimbal.Yaw * 0.01
            self.GimbalZoomLevel = gimbal.Zoom * 0.1
            self.GimbalDist = gimbal.Dist * 0.01

    # 广播遥测信息更新处理
    def on_bcst_tlm_rcv_event(self, bcst):
        if isinstance(bcst, BcstTlm):
            if self.RankNum != bcst.RankNum:
                self.RankNum = bcst.RankNum
                logging.info(f'UAV RankNum={self.RankNum}')
