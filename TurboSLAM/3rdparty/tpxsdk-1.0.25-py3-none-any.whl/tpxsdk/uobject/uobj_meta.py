# -*- coding: utf-8 -*-
from enum import IntEnum


class MetaDataType(IntEnum):
    """
    元数据类型编码
    """
    DT_S8 = 0x01   # 8-bit   signed integer
    DT_U8 = 0x00   # 8-bit unsigned integer
    DT_U16 = 0x02  # 16-bit unsigned integer
    DT_S16 = 0x03  # 16-bit   signed integer
    DT_U32 = 0x04  # 32-bit unsigned integer
    DT_S32 = 0x05  # 32-bit   signed integer
    DT_FP32 = 0x06  # 32-bit floating point


class UObjMeta(object):
    """
    UObject Meta结构,用于描述对象结构
    """

    def __init__(self):
        self.TypeName = ''  # 类型名称
        self.TypeId = 0  # 类型ID
        self.TypeSz = 0  # 对象数据大小
        self.InstCnt = 0  # 实例个数
        self.IsSetting = False  # 是否为配置项
        self.MemName = []  # 成员变量名称列表
        self.MemUnit = []  # 成员变量单位列表
        self.MemType = []  # 成员变量类型列表

    def mem_count(self) -> int:
        """
        成员变量个数
        """
        return len(self.MemName)

    def mem_size(self, mem_index) -> int:
        """
        获得指定Member索引的成员大小
        """
        if mem_index >= self.mem_count():
            return 0

        if (self.MemType[mem_index] == MetaDataType.DT_U8 or
                self.MemType[mem_index] == MetaDataType.DT_S8):
            return 1

        if (self.MemType[mem_index] == MetaDataType.DT_U16 or
                self.MemType[mem_index] == MetaDataType.DT_S16):
            return 2

        if (self.MemType[mem_index] == MetaDataType.DT_U32 or
                self.MemType[mem_index] == MetaDataType.DT_S32 or
                self.MemType[mem_index] == MetaDataType.DT_FP32):
            return 4

    @property
    def formatter(self):
        """
        获取UOBJ对象的字节序列化字符串
        """
        ret=[]
        for mt in self.MemType:
            if mt == MetaDataType.DT_U8:
                ret.append('B')
            if mt == MetaDataType.DT_S8:
                ret.append('b')
            if mt == MetaDataType.DT_U16:
                ret.append('H')
            if mt == MetaDataType.DT_S16:
                ret.append('h')
            if mt == MetaDataType.DT_U32:
                ret.append('I')
            if mt == MetaDataType.DT_S32:
                ret.append('i')
            if mt == MetaDataType.DT_FP32:
                ret.append('f')
        return ''.join(ret)
