# -*- coding: utf-8 -*-
import logging
import os
import json
from tpxsdk.uobject.uobj_meta import UObjMeta
from tpxsdk.uobject.uobj_base import UObjBase
from tpxsdk.uav.udev_type import UDevType

InvalidFieldId = 0xFFFFFFFF  # 无效FieldID编码


class UObjAdmin(object):
    def __init__(self, signature=0, dev_type=UDevType.UNKNOWN, only_setting=False):
        #region 成员变量
        self.ObjList = []  # UObject 对象列表
        self.MetaList = []  # UObject Meta列表
        self.Signature = signature  # UObject Meta签名
        self.DevType = dev_type  # 设备类型
        #endregion

        # 创建的是空Admin对象
        if UDevType.UNKNOWN == dev_type or 0 == signature:
            return

        # 加载Meta模板文件
        usr_root = os.path.expanduser('~')
        meta_fn = f'{usr_root}/UObjMeta/{self.Signature:X}-{self.DevType.name}.json'
        # Meta load fail to reset the array data
        if not self.load_meta(meta_fn, only_setting):
            self.ObjList = []
            self.MetaList = []
        else:
            logging.info(f'Use cache meta:{meta_fn}')

    def type_count(self):
        """
        UAV Object 类型总个数
        """
        return len(self.MetaList)

    def load_meta(self, meta_fn, only_setting=False):
        """
        从模板文件创建UObjMeta对象列表
        """
        if not os.path.exists(meta_fn):
            logging.error(f'Meta file {meta_fn} not exists!')
            return False

        self.MetaList.clear()
        self.ObjList.clear()
        with open(meta_fn, 'r') as f:
            str_sig = f.readline().strip()
            self.Signature = int(str_sig, 16)
            self.DevType = UDevType[f.readline().strip()]
            data = f.read()
            for m in json.loads(data):
                if len(m) == 0:
                    continue
                meta = UObjMeta()
                meta.TypeName = m['TypeName']
                meta.TypeId = m['TypeId']
                meta.TypeSz = m['TypeSz']
                meta.InstCnt = m['InstCnt']
                meta.IsSetting = m['IsSetting']
                meta.MemName = m['MemName']
                meta.MemUnit = m['MemUnit']
                meta.MemType = m['MemType']
                self.MetaList.append(meta)
        logging.info(f'Meta count={len(self.MetaList)}')

        # 构建对象列表
        for meta in self.MetaList:
            if only_setting and not meta.IsSetting:
                continue
            for i in range(meta.InstCnt):
                self.ObjList.append(UObjBase(meta, i))
        return True

    def save_meta(self, meta_fn=None) -> bool:
        """
        保存UObjMeta对象列表到模板文件
        """
        str_dev_type = str(self.DevType)
        str_dev_type = str_dev_type[str_dev_type.index('.') + 1:]
        if meta_fn is None:
            usr_root = os.path.expanduser('~')
            meta_fn = f'{usr_root}/UObjMeta/{self.Signature:X}-{str_dev_type}.json'
        #检查文件命名规则有效性
        meta_dir = os.path.dirname(meta_fn)
        if not os.path.exists(meta_dir):
            os.mkdir(meta_dir)
        #保存Meta数据

        # 解析python对象并输出到json文件
        with open(meta_fn, 'w') as f:
            f.write(f'{self.Signature:X}\n')
            f.write(f'{str_dev_type}\n')
            f.write('[\n')
            for obj in self.MetaList:
                json.dump(obj.__dict__, f, indent=4)
                f.write(',\n')
            f.write('{}\n')
            f.write(']\n')
        return True

    def save_setting(self, setting_fn) -> bool:
        """
        保存参数对象到指定参数文件
        """
        if setting_fn is None:
            logging.error('Setting file name is empty')
            return False

        #检查文件命名规则有效性
        setting_dir = os.path.dirname(setting_fn)
        if not os.path.exists(setting_dir):
            os.mkdir(setting_dir)
        str_dev_type = str(self.DevType)
        str_dev_type = str_dev_type[str_dev_type.index('.') + 1:]
        with open(setting_fn, 'w') as f:
            f.write(f'{self.Signature:X}\n{str_dev_type}\n')
            for obj in self.ObjList:
                if obj.IsSetting:
                    f.write(obj.to_string())
        return True

    @staticmethod
    def load_setting(setting_fn):
        """
        加载参数文件(.cfg)并创建新对象
        """
        if not os.path.exists(setting_fn):
            raise 'Setting file is not exits'

        file_name, file_extension = os.path.splitext(setting_fn)
        if '.cfg' not in file_extension.lower():
            raise 'Invalid setting file'

        with open(setting_fn, 'r') as f:
            str_sig = f.readline().strip()
            str_dev = f.readline().strip()
            admin = UObjAdmin(int(str_sig, 16), UDevType[str_dev.upper()], True)
            while True:
                line = f.readline().strip()
                if '' == line:  # end of file found
                    break
                # 删除整行注释
                if line.startswith('//') or line.startswith('#'):
                    continue
                # 删除行尾注释
                index = line.find('//')
                if index > 0:
                    line = line[0:index]

                if len(line) == 0:
                    continue
                admin.update_uobj_by_str(line)
        return admin

    def get_type_id(self, str_type):
        """
        获取TypeName对应的TypeID
        """
        # 简化类型前缀
        if str_type.lower().startswith('uobj'):
            str_type = str_type[4:]

        for m in self.MetaList:
            if m.TypeName == str_type:
                return [True, m.TypeId]
        return [False, 0xFF]

    def get_type_name(self, type_id: int):
        """
        获取TypeID对应的TypeName
        """
        for m in self.MetaList:
            if m.TypeId == type_id:
                return m.TypeName
        return None

    #------------------------------------------------------------------------------
    # 对象集合获取
    #------------------------------------------------------------------------------
    def get_uobjs_by_id(self, type_id: int):
        """
        按类型编码获得对象集合
        @type type_id: 类型编码
        """
        ret = []
        for obj in self.ObjList:
            if obj.Meta.TypeId == type_id:
                ret.append(obj)
        return ret

    def get_uobjs_by_str(self, str_type: str):
        """
        按类型字符串获得对象集合
        """
        # remove prefix "UObj"
        if str_type.lower().startswith('uobj'):
            str_type = str_type[4:]
        ret = []
        for obj in self.ObjList:
            if obj.Meta.TypeName == str_type:
                ret.append(obj)
        return ret

    # ------------------------------------------------------------------------------
    # 对象单例获取
    # ------------------------------------------------------------------------------
    def get_uobj_by_str(self, str_type):
        """
        按类型字符串和实例号获得对象
        """
        # remove prefix "UObj"
        if str_type.lower().startswith('uobj'):
            str_type = str_type[4:]
        field_id = self.parse_field_id(str_type)

        for obj in self.ObjList:
            if obj.Meta.TypeId == UObjAdmin.type_id(field_id) and obj.InstId == UObjAdmin.inst_id(field_id):
                return obj
        return None

    def get_uobj_by_field_id(self, field_id):
        """
        按类型编码和实例号获得对象
        """
        type_id = self.type_id(field_id)
        inst_id = self.inst_id(field_id)

        for obj in self.ObjList:
            if obj.Meta.TypeId == type_id and obj.InstId == inst_id:
                return obj
        return None

    #------------------------------------------------------------------------------
    # 对象更新
    #------------------------------------------------------------------------------
    def update_uobj_by_str(self, para: str):
        """
        更新UObj对象到当前列表,支持参数格式如下：
        XXX.yyy=ZZZ
        XXX[i].yyy=ZZZ
        """
        para = para.replace(' ', '')
        segs = para.split('=')
        field_id = self.parse_field_id(segs[0])
        return self.set_value_by_str(field_id, segs[1])

    def update_uobj(self, obj: UObjBase):
        """
        更新UObj对象到当前列表
        """
        ori_obj = self.get_uobj_by_field_id(obj.field_id())
        if ori_obj is None:
            return False
        return ori_obj.update(obj.to_bytes(), 0)

    #------------------------------------------------------------------------------
    # 对象值读取&写入
    #------------------------------------------------------------------------------
    def set_value(self, field_id, val) -> bool:
        """
        设置FieldID对应的Value对象
        """
        if not self.is_valid_field_id(field_id):
            return False

        obj = self.get_uobj_by_field_id(field_id)
        mem_id = self.mem_id(field_id)

        if obj is None or 0 == mem_id:
            return False

        return obj.member_update(mem_id - 1, val) > 0

    def set_value_by_str(self, field_id, val: str) -> bool:
        """
        设置FieldID对应的Value对象
        """
        if not self.is_valid_field_id(field_id):
            return False

        obj = self.get_uobj_by_field_id(field_id)
        mem_id = self.mem_id(field_id)

        if obj is None or 0 == mem_id:
            return False

        return obj.member_update_by_str(mem_id - 1, val) > 0

    #------------------------------------------------------------------------------
    # FieldID 编解码处理函数
    #------------------------------------------------------------------------------
    @staticmethod
    def type_id(field_id: int):
        """Field类型解码
        """
        return (field_id & 0xFF000000) >> 24

    @staticmethod
    def mem_id(field_id: int):
        """Field成员解码
        """
        return (field_id & 0x00FF0000) >> 16

    @staticmethod
    def inst_id(field_id: int):
        """Field实例解码
        """
        return field_id & 0x0000FFFF

    @staticmethod
    def gen_field_id(type_id: int, mem_id: int, inst_id: int):
        """Field编码【三段法】
        """
        return (type_id & 0xFF) << 24 | (mem_id & 0xFF) << 16 | (inst_id & 0xFFFF)

    @staticmethod
    def get_field_id(obj: UObjBase, mem_id=0):
        """
        Field编码【对象法+特定成员】
        """
        type_id = obj.Meta.TypeId
        inst_id = obj.InstId
        return (type_id & 0xFF) << 24 | (mem_id & 0xFF) << 16 | (inst_id & 0xFFFF)

    def parse_field_id(self, para) -> int:
        """
        解析字符串获得对应的FieldID
        """
        left_bracket = para.find('[')
        right_bracket = para.find(']')
        comma = para.find('.')
        # Not Match Brackets
        if left_bracket * right_bracket < 0:
            raise Exception(f'Invalid FieldName:{para}')

        if -1 == left_bracket and -1 == right_bracket:
            if -1 == comma:  # Format: 'UObjxxx'
                ret, type_id = self.get_type_id(para)
                if not ret:
                    return InvalidFieldId
                return UObjAdmin.gen_field_id(type_id, 0, 0)

            # Format: 'UObjxxx.yyyy'
            type_name = para[:comma]
            ret, type_id = self.get_type_id(type_name)
            if not ret:
                raise Exception(f'Invalid FieldName:{para}')

            mem_name = para[(comma + 1):]
            uobjs = self.get_uobjs_by_id(type_id)
            if len(uobjs) == 0:
                raise Exception(f'Invalid FieldName:{para}')

            mem_id = 1 + uobjs[0].Meta.MemName.index(mem_name)
            if mem_id > 0:
                inst_id = 0
                return UObjAdmin.gen_field_id(type_id, mem_id, inst_id)
            raise Exception(f'Invalid FieldName:{para}')

        str_inst_id = para[left_bracket + 1: right_bracket]
        inst_id = int(str_inst_id)

        str_type_name = para[:left_bracket]
        ret, type_id = self.get_type_id(str_type_name)
        if not ret:
            raise Exception(f'Invalid FieldName:{str_type_name}')

        if -1 == comma:  # Format: 'UObjxxx[i]'
            mem_id = 0
        else:  # Format: 'UObjxxx[i].yyyy'
            mem_name = para[(comma + 1):]
            uobjs = self.get_uobjs_by_id(type_id)
            if len(uobjs) == 0:
                return InvalidFieldId

            idx = uobjs[0].Meta.MemName.index(mem_name)
            if idx < 0:
                raise Exception(f'Invalid Field Name: {para}')
            mem_id = 1 + idx

        return UObjAdmin.gen_field_id(type_id, mem_id, inst_id)

    def field_id_to_str(self, field_id) -> str:
        """
        翻译FieldId为对应的字符串
        """
        if self.is_valid_field_id(field_id):
            return ''

        obj = self.get_uobj_by_field_id(field_id)
        mem_id = self.mem_id(field_id)

        if obj is None:
            return ''

        return obj.friend_nm(mem_id)

    def is_valid_field_id(self, field_id: int) -> bool:
        """
        检测FieldId是否为有效
        """
        obj = self.get_uobj_by_field_id(field_id)
        return obj is not None
