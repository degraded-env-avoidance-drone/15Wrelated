# -*- coding: utf-8 -*-
import struct
import logging
from tpxsdk.uobject.uobj_meta import MetaDataType


#----------------------------------------------------------------
# UAV Object 对象基类
#----------------------------------------------------------------
class UObjBase(object):
    def __init__(self, meta, inst_id):
        self.Meta = meta
        self.IsSetting = meta.IsSetting  # 是否为参数对象
        self.Member = {'': 0}  # 成员变量数组[通过成员名称访问]
        self.InstId = inst_id  # 实例对象编码
        self.Member = {}
        # 初始化所有成员变量为0
        for nm in meta.MemName:
            self.Member[nm] = 0

    def __str__(self):
        return self.friend_nm()

    def __getitem__(self, key):
        if isinstance(key, str):
            return self.mem_value(key)

        if isinstance(key, int):
            mem_nm = self.Meta.MemName[key]
            return self.mem_value(mem_nm)

        return None

    # 结构对象大小，单位字节
    def __len__(self):
        return self.Meta.TypeSz

    @property
    def size(self) -> int:  # 结构对象大小，单位字节
        return self.Meta.TypeSz

    @property
    def is_setting(self) -> bool:  # 是否为参数对象
        return self.Meta.IsSetting

    @property
    def type_name(self) -> str:
        return self.Meta.TypeName

    @property
    def inst_id(self) -> int:  # 结构对象大小，单位字节
        return self.InstId

    def friend_nm(self, mem_id=0) -> str:
        """
        获得当前对象的可读字符串名称
        """
        if 0 == mem_id:
            if self.Meta.InstCnt == 1:
                return f'{self.type_name}'
            return f'{self.type_name}[{self.InstId}]'
        # Multi instance
        if self.Meta.InstCnt == 1:
            return f'{self.type_name}.{self.Meta.MemName[mem_id - 1]}'
        return f'{self.type_name}[{self.InstId}].{self.Meta.MemName[mem_id - 1]}'

    def field_id(self, mem_nm=None):
        """
        获得指定UObject对象和对应成员名称的FieldId
        """
        type_id = self.Meta.TypeId
        inst_id = self.InstId
        mem_id = self.Meta.MemName.index(mem_nm) + 1 if mem_nm is not None else 0
        return (type_id & 0xFF) << 24 | (mem_id & 0xFF) << 16 | (inst_id & 0xFFFF)

    def mem_unit(self, mem_nm):
        """
        根据Member Name获得对应单位字符串
        """
        idx = self.Meta.MemName.index(mem_nm)
        return self.Meta.MemUnit[idx]

    def mem_value(self, mem_nm):
        """
        根据Member Name获得对应成员变量值
        """
        return self.Member[mem_nm]

    def to_string(self):
        """
        将当前对象详细信息转换为字符串
        """
        ret = ''
        for p in self.Member:
            m_val = self.Member[p]
            if isinstance(m_val, float):
                m_val = round(m_val, 5)
            str_unit = self.mem_unit(p)
            if len(str_unit) == 0:
                ret += f'{self.friend_nm()}.{p}={m_val}'
            else:
                ret += f'{self.friend_nm()}.{p}={m_val} //{str_unit}'
            ret += '\n'
        return ret

    def mem_to_bytes(self, mem_index):
        """
        根据Meta信息将Members值转换为字节数组 失败返回空列表
        """
        val = self.Member[self.Meta.MemName[mem_index]]
        dtype = self.Meta.MemType[mem_index]
        if MetaDataType.DT_U8 == dtype:
            return struct.pack('B', val)
        if MetaDataType.DT_S8 == dtype:
            return struct.pack('b', val)
        if MetaDataType.DT_U16 == dtype:
            return struct.pack('H', val)
        if MetaDataType.DT_S16 == dtype:
            return struct.pack('h', val)
        if MetaDataType.DT_U32 == dtype:
            return struct.pack('L', val)
        if MetaDataType.DT_S32 == dtype:
            return struct.pack('l', val)
        if MetaDataType.DT_FP32 == dtype:
            return struct.pack('f', val)

        return []

    def member_update(self, mem_index, data: bytes):
        """
        根据Meta信息通过字节数组更新Members值,返回更新使用字节大小
        """
        dtype = self.Meta.MemType[mem_index]
        val = None
        if MetaDataType.DT_U8 == dtype:
            val = struct.unpack('B', data[:1])[0]
        if MetaDataType.DT_S8 == dtype:
            val = struct.unpack('b', data[:1])[0]
        if MetaDataType.DT_U16 == dtype:
            val = struct.unpack('H', data[:2])[0]
        if MetaDataType.DT_S16 == dtype:
            val = struct.unpack('h', data[:2])[0]
        if MetaDataType.DT_U32 == dtype:
            val = struct.unpack('I', data[:4])[0]
        if MetaDataType.DT_S32 == dtype:
            val = struct.unpack('i', data[:4])[0]
        if MetaDataType.DT_FP32 == dtype:
            val = struct.unpack('f', data[:4])[0]

        self.Member[self.Meta.MemName[mem_index]] = val
        return 0 if val is None else self.Meta.mem_size(mem_index)

    def member_update_by_str(self, mem_index, data: str):
        """
        根据Meta信息通过字符串更新Members值,返回更新内容占用字节大小
        """
        dtype = self.Meta.MemType[mem_index]
        val = None
        if MetaDataType.DT_U8 == dtype:
            val = int(data) % 256
        if MetaDataType.DT_S8 == dtype:
            val = int(data) % 256
            val -= 128 if val >= 128 else 0
        if MetaDataType.DT_U16 == dtype:
            val = int(data) % 65536
        if MetaDataType.DT_S16 == dtype:
            val = int(data) % 65536
            val -= 32767 if val >= 32767 else 0
        if MetaDataType.DT_U32 == dtype:
            val = int(data)
        if MetaDataType.DT_S32 == dtype:
            val = int(data)
        if MetaDataType.DT_FP32 == dtype:
            val = float(data)

        self.Member[self.Meta.MemName[mem_index]] = val
        return 0 if val is None else self.Meta.mem_size(mem_index)

    def to_bytes(self):
        """
        UObj对象转换为字节数组
        """
        ret = bytearray(self.size)
        idx = 0
        for i in range(self.Meta.mem_count()):
            for c in self.mem_to_bytes(i):
                ret[idx] = c
                idx += 1
        return ret

    def update(self, data: bytes):
        """
        将字节数组更新UObj对象
        """
        index = 0
        for i in range(self.Meta.mem_count()):
            try:
                index += self.member_update(i, data[index:])
            except Exception as e:
                logging.error(f'{self.friend_nm()} Update fail, Data={data} Exp={e}')
                return False

        return index == self.Meta.TypeSz
